package eco;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import eco.partidosBase.PartidoBaseGovernistaController;

/**
 * Classe para testes de PartidoController.
 *
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */
class PartidoControllerTest {

	private PartidoBaseGovernistaController pc;

@BeforeEach
	void setUp() throws Exception{
	pc = new PartidoBaseGovernistaController();
	pc.cadastrarPartido("ABC");
	pc.cadastrarPartido("DEF");
}

@Test
void testCadastrarPartidoNomeInvalido() {
	try {
		pc.cadastrarPartido(null);
		fail("Deveria ter lancado excecao pois nome do partido nao pode ser nulo");
	}catch (NullPointerException npe) {
		
	}
	
	try {
		pc.cadastrarPartido("    ");
		fail("Deveria ter lancado excecao pois nome do partido nao pode ser vazio");
	}catch (IllegalArgumentException iae) {
		
	}
}

@Test
void testCadastrarPartidoComNomeIgual() {
	try {
		pc.cadastrarPartido("ABC");
		fail("Deveria ter lancado excecao pois nome do partido ja foi cadastrado");
	}catch (IllegalArgumentException iae) {
		
	}
}

@Test
void testExibeBase() {
	assertEquals("ABC,DEF", pc.exibeBase());
	pc.cadastrarPartido("GHI");
	assertEquals("ABC,DEF,GHI", pc.exibeBase());
}








}