package eco;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controllers.PessoaController;
import controllers.ProposicaoController;

class ProposicaoControlllerTest {

	private PessoaController pc1;
	private ProposicaoController pl1;

	@BeforeEach
	void setUp() throws Exception {
		pl1 = new ProposicaoController();
		pc1 = new PessoaController();
		pc1.cadastrarPessoa("Plipox Poplx", "061444444-0", "RO", "trabalho", "DEF");
		pc1.cadastraDeputado("061444444-0", "30012019");
	}

	@Test
	public void testaCadastraPLdniInvalido() {

		try {
			pl1.cadastrarPL("0A1444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", true);
			fail("Erro ao cadastrar projeto: dni invalido");
		} catch (IllegalArgumentException iae) {
		}
		try {
			pl1.cadastrarPL(null, 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", true);
			fail("Erro ao cadastrar projeto: dni invalido");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPLSemEmenta() {

		try {
			pl1.cadastrarPL("061444444-0", 2016, "", "saude,educacao basica", "http://example.com/semana_saude", true);
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		} catch (IllegalArgumentException iae) {
		}

		try {
			pl1.cadastrarPL("061444444-0", 2016, null, "saude,educacao basica", "http://example.com/semana_saude",
					true);
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPLSemINteresses() {

		try {
			pl1.cadastrarPL("061444444-0", 2016, "Institui a semana da nutricao nas escolas", null,
					"http://example.com/semana_saude", true);
			fail("Erro ao cadastrar projeto: interesse nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
		}

		try {
			pl1.cadastrarPL("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "",
					"http://example.com/semana_saude", true);
			fail("Erro ao cadastrar projeto: interesse nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
		}

	}

	@Test
	public void testaCadastraPLSemURL() {

		try {
			pl1.cadastrarPL("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"", true);
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		} catch (IllegalArgumentException iae) {
		}

		try {
			pl1.cadastrarPL("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					null, true);
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPLPdniInvalido() {

		try {
			pl1.cadastrarPLP("0A1444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", "153");
			fail("Erro ao cadastrar projeto: dni invalido");
		} catch (IllegalArgumentException iae) {
		}
		try {
			pl1.cadastrarPLP(null, 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", "153");
			fail("Erro ao cadastrar projeto: dni invalido");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPLPSemEmenta() {

		try {
			pl1.cadastrarPLP("061444444-0", 2016, "", "saude,educacao basica", "http://example.com/semana_saude",
					"153");
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		} catch (IllegalArgumentException iae) {
		}

		try {
			pl1.cadastrarPLP("061444444-0", 2016, null, "saude,educacao basica", "http://example.com/semana_saude",
					"153");
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPLPSemINteresses() {

		try {
			pl1.cadastrarPLP("061444444-0", 2016, "Institui a semana da nutricao nas escolas", null,
					"http://example.com/semana_saude", "153");
			fail("Erro ao cadastrar projeto: interesse nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
		}

		try {
			pl1.cadastrarPLP("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "",
					"http://example.com/semana_saude", "153");
			fail("Erro ao cadastrar projeto: interesse nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
		}

	}

	@Test
	public void testaCadastraPLPSemURL() {

		try {
			pl1.cadastrarPLP("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"", "153");
			fail("Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
		}

		try {
			pl1.cadastrarPLP("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					null, "153");
			fail("Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPLPSemArtigos() {

		try {
			pl1.cadastrarPLP("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", "");
			fail("Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
		}

		try {
			pl1.cadastrarPLP("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", null);
			fail("Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPECdniInvalido() {

		try {
			pl1.cadastrarPEC("0A1444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", "153");
			fail("Erro ao cadastrar projeto: dni invalido");
		} catch (IllegalArgumentException iae) {
		}
		try {
			pl1.cadastrarPEC(null, 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", "153");
			fail("Erro ao cadastrar projeto: dni invalido");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPECSemEmenta() {

		try {
			pl1.cadastrarPEC("061444444-0", 2016, "", "saude,educacao basica", "http://example.com/semana_saude",
					"153");
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		} catch (IllegalArgumentException iae) {
		}

		try {
			pl1.cadastrarPEC("061444444-0", 2016, null, "saude,educacao basica", "http://example.com/semana_saude",
					"153");
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPECSemINteresses() {

		try {
			pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", null,
					"http://example.com/semana_saude", "153");
			fail("Erro ao cadastrar projeto: interesse nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
		}

		try {
			pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "",
					"http://example.com/semana_saude", "153");
			fail("Erro ao cadastrar projeto: interesse nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
		}

	}

	@Test
	public void testaCadastraPECSemURL() {

		try {
			pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"", "153");
			fail("Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
		}

		try {
			pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					null, "153");
			fail("Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void testaCadastraPECSemArtigos() {

		try {
			pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", "");
			fail("Erro ao cadastrar projeto: artigo nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
		}

		try {
			pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
					"http://example.com/semana_saude", null);
			fail("Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	public void TestaexibirProjeto() {
		pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", "153");
		assertEquals("Projeto de Emenda Constitucional - PEC 1/2016 - 061444444-0 - Institui a semana da nutricao nas escolas - 153 - EM VOTACAO (CCJC)", pl1.exibirProjeto("PEC 1/2016"));
	}
	
	@Test
	public void testaConstainsProjeto() {
		pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", "153");
		assertTrue(pl1.containsProjeto("PEC 1/2016"));
	}
	
	@Test 
	public void testaGetSituacao() {
		pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", "153");
		assertEquals("EM VOTACAO (CCJC)", pl1.getSituacao("PEC 1/2016"));
		
	}
	//@Test 
	//public void testaAddTramite() {
	//	pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
	//			"http://example.com/semana_saude", "153");
			
	//}
	
	@Test 
	public void testaSetSituacaoAtual() {
		pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", "153");
		pl1.setSituacaoAtual("PEC 1/2016", "APROVADO");
		assertEquals("APROVADO", pl1.getSituacao("PEC 1/2016"));
		
	}
	
	@Test
	public void testaGetConclusivo() {
		pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", "153");
		assertFalse(pl1.getConclusivo("PEC 1/2016"));
	
	
	
	pl1.cadastrarPL("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
			"http://example.com/semana_saude", true);
		assertTrue(pl1.getConclusivo("PL 1/2016"));	
}
	
	@Test
	public void testaGetInteresse() {
		pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", "153");
		List<String> lista = pl1.getInteresses("PEC 1/2016");
		String frase = "";
		for (String s : lista) {
			frase += s;
		}
		assertEquals("saudeeducacao basica", frase);
	}
	
	@Test
	public void testaGetAutor() {
		
		pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", "153");
		
		assertEquals("061444444-0", pl1.getAutor("PEC 1/2016"));
	}
	
	@Test
	public void testaGetTipo() {
		pl1.cadastrarPEC("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", "153");
		pl1.cadastrarPL("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", true);
		pl1.cadastrarPLP("061444444-0", 2016, "Institui a semana da nutricao nas escolas", "saude,educacao basica",
				"http://example.com/semana_saude", "153");
		
		assertEquals("PEC", pl1.getTipo("PEC 1/2016"));
		
		assertEquals("PL", pl1.getTipo("PL 1/2016"));
		
		assertEquals("PLP", pl1.getTipo("PLP 1/2016"));
	}
}












