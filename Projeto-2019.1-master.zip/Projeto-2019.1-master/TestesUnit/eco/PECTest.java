package eco;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controllers.PessoaController;
import eco.proposicao.PEC;

class PECTest {

	
	private PessoaController pc1;
	private PEC pl1;
	
	@BeforeEach
	void setUp()throws Exception{
		pc1 = new PessoaController();
		pc1.cadastrarPessoa("Plipox Poplx","061444444-0", "RO","trabalho","DEF");
		pc1.cadastraDeputado("061444444-0", "30012019");
	}
	
	
	@Test
	public void testaPECsemCodigo() {
		String interesses = "saude,educacao basica";
		String[] interessesSeparados = interesses.split(",");
		List<String> todosInteresses = new ArrayList<>();
		
		for (String interesse : interessesSeparados) {
			todosInteresses.add(interesse);
		}
		
	try {
		pl1 = new PEC("PL 1/2016","0A1444444-0", 2016, "Institui a semana da nutricao nas escolas",todosInteresses,"http://example.com/semana_saude", "123" );
		fail("Erro ao cadastrar projeto: dni invalido");
	}catch(IllegalArgumentException iae) {
}
	
	try {
		pl1 = new PEC("PL 1/2016",null, 2016, "Institui a semana da nutricao nas escolas",todosInteresses,"http://example.com/semana_saude", "123" );
		fail("Erro ao cadastrar projeto: dni invalido");
	}catch(NullPointerException npe) {
}
	
	
	
	}
	
	@Test
	public void testaPECSemEmenta() {
		String interesses = "saude,educacao basica";
		String[] interessesSeparados = interesses.split(",");
		List<String> todosInteresses = new ArrayList<>();
		
		for (String interesse : interessesSeparados) {
			todosInteresses.add(interesse);
		}
		
		try {
			pl1 = new PEC("PL 1/2016","061444444-0", 2016, "",todosInteresses,"http://example.com/semana_saude", "123");
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		}catch(IllegalArgumentException iae) {
	}
		
		try {
			pl1 = new PEC("PL 1/2016","061444444-0", 2016, null,todosInteresses,"http://example.com/semana_saude", "123");
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		}catch(NullPointerException npe) {
	}
	
}
	
	@Test
	public void testaPECSemURL() {
		String interesses = "saude,educacao basica";
		String[] interessesSeparados = interesses.split(",");
		List<String> todosInteresses = new ArrayList<>();
		
		for (String interesse : interessesSeparados) {
			todosInteresses.add(interesse);
		}
		
		try {
			pl1 = new PEC("PL 1/2016","061444444-0", 2016, "Institui a semana da nutricao nas escolas",todosInteresses,"", "123" );
			fail("Erro ao cadastrar projeto: url nao pode ser vazia ou nula");
		}catch(IllegalArgumentException iae) {
	}
		
		try {
			pl1 = new PEC("PL 1/2016","061444444-0", 2016, "Institui a semana da nutricao nas escolas",todosInteresses,null, "123");
			fail("Erro ao cadastrar projeto: url nao pode ser vazia ou nula");
		}catch(NullPointerException npe) {
	}
	
}
	
	@Test
	public void testaPECSemArtigo() {
		String interesses = "saude,educacao basica";
		String[] interessesSeparados = interesses.split(",");
		List<String> todosInteresses = new ArrayList<>();
		
		for (String interesse : interessesSeparados) {
			todosInteresses.add(interesse);
		}
		
		try {
			pl1 = new PEC("PL 1/2016","061444444-0", 2016, "Institui a semana da nutricao nas escolas",todosInteresses,"http://example.com/semana_saude", "" );
			fail("Erro ao cadastrar projeto: artigo nao pode ser vazia ou nula");
		}catch(IllegalArgumentException iae) {
	}
		
		try {
			pl1 = new PEC("PL 1/2016","061444444-0", 2016, "Institui a semana da nutricao nas escolas",todosInteresses,"http://example.com/semana_saude", null);
			fail("Erro ao cadastrar projeto: artigo nao pode ser vazia ou nula");
		}catch(NullPointerException npe) {
	}
	
}
	
	
	
	
}

