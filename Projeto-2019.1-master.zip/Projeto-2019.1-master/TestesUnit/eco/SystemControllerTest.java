package eco;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controllers.SystemController;

class SystemControllerTest {

	private SystemController sc;

	@BeforeEach
	void setUp() throws Exception {
		this.sc = new SystemController();

		this.sc.cadastrarPessoa("M1", "071111111-0", "PB", "educacao,seguranca publica,saude", "PartidoGov");
		this.sc.cadastrarPessoa("M2", "071222222-0", "PE", "educacao,seguranca publica,saude", "PartidoGov");
		this.sc.cadastrarPessoa("M3", "071333333-0", "PI", "saude,seguranca publica,trabalho", "PartidoGov");

		this.sc.cadastrarDeputado("071111111-0", "29022016");
		this.sc.cadastrarDeputado("071222222-0", "29022016");
		this.sc.cadastrarDeputado("071333333-0", "29022016");

		this.sc.cadastrarComissao("CGOV", "071111111-0,071222222-0,071333333-0");
	}

	// Testes de excecao da Comissao
	@Test
	void testCadastrarComissaoTemaVazio() {
		try {
			this.sc.cadastrarComissao("   ", "071111111-0,071222222-0,071333333-0");
		} catch (IllegalArgumentException e) {
			assertEquals("Erro ao cadastrar comissao: tema nao pode ser vazio ou nulo", e.getMessage());
		}
	}

	@Test
	void testCadastrarComissaoTemaNull() {
		try {
			this.sc.cadastrarComissao(null, "071111111-0,071222222-0,071333333-0");
		} catch (NullPointerException e) {
			assertEquals("Erro ao cadastrar comissao: tema nao pode ser vazio ou nulo", e.getMessage());
		}
	}

	@Test
	void testCadastrarComissaoPolitocosVazio() {
		try {
			this.sc.cadastrarComissao("CGOV", "   ");
		} catch (IllegalArgumentException e) {
			assertEquals("Erro ao cadastrar comissao: lista de politicos nao pode ser vazio ou nulo", e.getMessage());
		}
	}

	@Test
	void testCadastrarComissaoPoliticosNull() {
		try {
			this.sc.cadastrarComissao("CGOV", null);
		} catch (NullPointerException e) {
			assertEquals("Erro ao cadastrar comissao: lista de politicos nao pode ser vazio ou nulo", e.getMessage());
		}
	}

	@Test
	void testCadastrarComissaoExistente() {
		try {
			this.sc.cadastrarComissao("CGOV", "071222111-0,071333222-0,071334443-0");
		} catch (IllegalArgumentException e) {
			assertEquals("Erro ao cadastrar comissao: tema existente", e.getMessage());
		}
	}

	@Test
	void testCadastraComissaoDniInvalido() {
		try {
			this.sc.cadastrarComissao("GOV", "ABC222111-0,071333222-0,071334443-0");
		} catch (IllegalArgumentException e) {
			assertEquals("Erro ao cadastrar comissao: dni invalido", e.getMessage());
		}
	}

	@Test
	void testCadastraComissaoPessoaInexistente() {
		try {
			this.sc.cadastrarComissao("GOV", "070000000-0,071222222-0,071333333-0");
		} catch (NullPointerException e) {
			assertEquals("Erro ao cadastrar comissao: pessoa inexistente", e.getMessage());
		}
	}

	@Test
	void testCadastraComissaoPessoaNaoDeputado() {
		this.sc.cadastrarPessoa("M4", "099408420-0", "RJ", "Nutricao");
		try {
			this.sc.cadastrarComissao("GOV", "099408420-0,071222222-0,071333333-0");
		} catch (IllegalArgumentException e) {
			assertEquals("Erro ao cadastrar comissao: pessoa nao eh deputado", e.getMessage());
		}
	}

	@Test
	void testVotarComissao() {
		//Verifica quantas leis aprovadas tem o deputado
		assertEquals("POL: M1 - 071111111-0 (PB) - PartidoGov - Interesses: educacao,seguranca publica,saude - 29/02/2016 - 0 Leis",this.sc.exibirPessoa("071111111-0"));
		
		this.sc.cadastrarPartido("P1");
		this.sc.cadastrarPL("071111111-0", 2018, "ementa", "saude", "url", false);
		try {
			assertEquals(false, this.sc.votarComissao("PL 1/2018", "GOVERNISTA", "plenario"));
			fail("deveria ter lancado excecao: CCJC nao cadastrada");
		} catch (NullPointerException npe) {

		}

		try {
			assertEquals(false, this.sc.votarComissao("PL 3/2018", "GOVERNISTA", "plenario"));
			fail("deveria ter lancado excecao: proposicao nao cadastrada");
		} catch (NullPointerException npe) {

		}

		this.sc.cadastrarComissao("CCJC", "071111111-0,071222222-0,071333333-0");

		// Teste para recusar
		assertEquals(false, this.sc.votarComissao("PL 1/2018", "GOVERNISTA", "plenario"));

		// Teste se realmente recusa
		assertEquals("REJEITADO (CCJC), EM VOTACAO (Plenario)", this.sc.exibirTramitacao("PL 1/2018"));

		this.sc.cadastrarPL("071111111-0", 2018, "ementa", "saude", "url", false);

		// teste para aceitar
		assertEquals(true, this.sc.votarComissao("PL 2/2018", "OPOSICAO", "plenario"));

		// Teste se realmente aprova
		assertEquals("APROVADO (CCJC), EM VOTACAO (Plenario)", this.sc.exibirTramitacao("PL 2/2018"));

		this.sc.cadastrarPL("071111111-0", 2018, "ementa", "saude", "url", true);

		// Faz ser aprovado no plenario
		this.sc.votarPlenario("PL 2/2018", "OPOSICAO", "071111111-0,071222222-0,071333333-0");

		// Teste se realmente aprova
		assertEquals("APROVADO (CCJC), APROVADO (Plenario)", this.sc.exibirTramitacao("PL 2/2018"));
		
		//Verifica se adiciona lei aprovada ao deputado
		assertEquals("POL: M1 - 071111111-0 (PB) - PartidoGov - Interesses: educacao,seguranca publica,saude - 29/02/2016 - 1 Leis",this.sc.exibirPessoa("071111111-0"));
		
		try {
			assertEquals(false, this.sc.votarComissao("PL 3/2018", "GOVERNISTA", "plenario"));
			fail("deveria ter lancado excecao: pl conclusiva nao pode ter plenario como destino");
		} catch (IllegalArgumentException iae) {

		}

	}

}