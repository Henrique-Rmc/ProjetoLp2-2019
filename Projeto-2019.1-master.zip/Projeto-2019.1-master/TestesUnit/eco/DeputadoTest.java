package eco;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import eco.pessoa.Deputado;

/**
 * Classe para testes de Deputado.
 *
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */
class DeputadoTest {

	private Deputado d1;
	private Deputado d2;

	@BeforeEach
	void setUp() throws Exception {
		d1 = new Deputado("20041996");
	}

	@Test
	void testDeputadoComDataVazia() {
		try {
			d2 = new Deputado("     ");
			fail("Deveria ter lancado excecao pois data foi passada vazia");
		}catch (IllegalArgumentException iae) {
			
		}
		
		try {
			d2 = new Deputado(null);
			fail("Deveria ter lancado excecao pois data foi passada nula");
		}catch (NullPointerException npe) {
			
		}
		
	}
	
	@Test
	void testDeputadoComDataInvalidaOuFutura() {
		try {
			d2 = new Deputado("12478");
			fail("Deveria ter lancado excecao pois data foi passada no formato invalido");
		}catch (IllegalArgumentException iae) {
			
		}
		
		try {
			d2 = new Deputado("12/08/2017");
			fail("Deveria ter lancado excecao pois data foi passada no formato invalido");
		}catch (IllegalArgumentException iae) {
			
		}
		
		try {
			d2 = new Deputado("12082019");
			fail("Deveria ter lancado excecao pois foi passada data futura");
		}catch (IllegalArgumentException iae) {
			
		}
		
		try {
			d2 = new Deputado("01012020");
			fail("Deveria ter lancado excecao pois foi passada data futura");
		}catch (IllegalArgumentException iae) {
			
		}
	}

	@Test
	void testGetDataDeInicio() {
		assertEquals("20/04/1996", d1.getDataDeInicio());
		d2 = new Deputado("12082018");
		assertEquals("12/08/2018", d2.getDataDeInicio());
	}

	@Test
	void testGetNumeroDeLeis() {
		assertEquals(0,d1.getNumeroDeLeis());
	}

	@Test
	void testAddNumeroDeLeis() {
		d2 = new Deputado("12082018");
		assertEquals(0,d2.getNumeroDeLeis());
		//Mudando
		d2.addNumeroDeLeis();
		//Verificando se realmente mudou
		assertEquals(1,d2.getNumeroDeLeis());
	}

	@Test
	void testGetDetalhes() {
		assertEquals("POL: Jose - 000000-0 (PB) - 20/04/1996 - 0 Leis",d1.getDetalhes("Jose - 000000-0 (PB)"));
		d2 = new Deputado("12082018");
		d2.addNumeroDeLeis();
		d2.addNumeroDeLeis();
		assertEquals("POL: Maria - 111111-1 (PE) - ABC - Interesses: educacao,saude - 12/08/2018 - 2 Leis",d2.getDetalhes("Maria - 111111-1 (PE) - ABC - Interesses: educacao,saude"));
	}

}
