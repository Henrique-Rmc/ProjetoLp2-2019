package eco;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controllers.SystemController;

class VotacaoPlenarioTest {
	
	private SystemController sc;
	
	@BeforeEach
	void setUp()throws Exception{
		this.sc = new SystemController();
		
		this.sc.cadastrarPessoa("P1", "071111111-0", "PB", "educacao,seguranca publica,saude", "PartidoGov");
		this.sc.cadastrarPessoa("P2", "071222222-0", "PE", "educacao,seguranca publica,saude", "PartidoGov");
		this.sc.cadastrarPessoa("P3", "071333333-0", "PI", "saude,seguranca publica,trabalho", "PartidoGov");
		this.sc.cadastrarPessoa("P4", "071444444-0", "PI", "saude,seguranca publica,trabalho", "PartidoGov");
		this.sc.cadastrarPessoa("P5", "071555555-0", "PI", "nutricao", "PartidoGov");
		this.sc.cadastrarPessoa("P6", "071666666-0", "RO", "educacao,seguranca publica,saude", "PartidoOpo");
		this.sc.cadastrarPessoa("P7", "071777777-0", "RO", "educacao,seguranca publica,saude", "PartidoOpo");
		this.sc.cadastrarPessoa("P8", "071888888-0", "RO", "saude,seguranca publica,trabalho", "PartidoOpo");
		this.sc.cadastrarPessoa("P9", "071999999-0", "RO", "saude,seguranca publica,trabalho", "PartidoOpo");

		this.sc.cadastrarDeputado("071111111-0", "29022016");
		this.sc.cadastrarDeputado("071222222-0", "29022016");
		this.sc.cadastrarDeputado("071333333-0", "29022016");
		this.sc.cadastrarDeputado("071444444-0", "29022016");
		this.sc.cadastrarDeputado("071555555-0", "29022016");
		this.sc.cadastrarDeputado("071666666-0", "29022016");
		this.sc.cadastrarDeputado("071777777-0", "29022016");
		this.sc.cadastrarDeputado("071888888-0", "29022016");
		this.sc.cadastrarDeputado("071999999-0", "29022016");
		
		this.sc.cadastrarComissao("CGOV", "071111111-0,071222222-0,071333333-0,071444444-0,071555555-0");
	}
	
	
	@Test
	void testVotarPlenario() {
		this.sc.cadastrarComissao("CCJC", "071111111-0,071222222-0,071333333-0");
		this.sc.cadastrarPL("071333333-0", 2018, "Ementa PLnconc", "cidadania,educacao basica", "http", false);
		this.sc.votarComissao("PL 1/2018", "GOVERNISTA", "CGOV");
		this.sc.votarComissao("PL 1/2018", "OPOSICAO", "plenario");
		assertFalse(this.sc.votarPlenario("PL 1/2018", "GOVERNISTA", "071111111-0,071222222-0,071333333-0,071444444-0,071555555-0,071666666-0,071777777-0,071888888-0,071999999-0"));
	}
	
	@Test
	void testExcecaoCCJC() {
		try {
			assertEquals(false, this.sc.votarPlenario("PL 1/2018", "GOVERNISTA", "071111111-0,071222222-0,071333333-0,071444444-0,071555555-0,071666666-0,071777777-0,071888888-0,071999999-0"));
			fail("deveria ter lancado excecao: CCJC nao cadastrada");
		} catch (NullPointerException npe) {

		}
	}
	
	@Test
	void testExcecaoProposicaoNaoCadastrada() {
		try {
			assertEquals(false, this.sc.votarPlenario("PL 5/2016", "GOVERNISTA", "071111111-0,071222222-0,071333333-0,071444444-0,071555555-0,071666666-0,071777777-0,071888888-0,071999999-0"));
			fail("deveria ter lancado excecao: proposicao nao cadastrada");
		} catch (NullPointerException npe) {

		}
	}
	
	@Test
	void testExcecaoCodigoNull() {
		try {
			assertEquals(false, this.sc.votarPlenario(null, "GOVERNISTA", "071111111-0,071222222-0,071333333-0,071444444-00"));
			fail("deveria ter lancado excecao: codigo nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
			
		}
	}
	
	@Test
	void testExcecaoCodigoVazio() {
		try {
			assertEquals(false, this.sc.votarPlenario("  ", "GOVERNISTA", "071111111-0,071222222-0,071333333-0,071444444-00"));
			fail("deveria ter lancado excecao: codigo nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
			
		}
	}
	
	@Test
	void testExcecaoStatusVazio() {
		try {
			assertEquals(false, this.sc.votarPlenario("PL 1/2108", "    ", "071111111-0,071222222-0,071333333-0,071444444-00"));
			fail("deveria ter lancado excecao: codigo nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
			
		}
	}
	
	@Test
	void testExcecaoStatusNull() {
		try {
			assertEquals(false, this.sc.votarPlenario("PL 1/2018", null, "071111111-0,071222222-0,071333333-0,071444444-00"));
			fail("deveria ter lancado excecao: codigo nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
			
		}
	}
	
	@Test
	void testExcecaStatusInvalido() {
		try {
			assertEquals(false, this.sc.votarPlenario("PL 1/2018", "PIZZA", "071111111-0,071222222-0,071333333-0,071444444-00"));
			fail("deveria ter lancado excecao: status invalido");
		} catch (NullPointerException npe) {
			
		}
	}
	
	@Test
	void testExcecaoPresentesVazio() {
		try { 
			assertEquals(false, this.sc.votarPlenario("PL 1/2018", "GOVERNISTA", "  "));
			fail("deveria ter lancado excecao: presentes vazio");
		} catch (IllegalArgumentException iea) {
			
		}
	}
	
	@Test
	void testExcecaoTramitacaoComissao() {
		try {
			assertEquals(false, this.sc.votarPlenario("PL 1/2018", "GOVERNISTA", "  "));
			fail("deveria ter lancado excecao: presentes vazio");
		} catch (IllegalArgumentException iea) {
			
		}
	}
	
	@Test
	void testExcecaDniInvalido() {
		try {
			assertEquals(false, this.sc.votarPlenario("PL 1/2018", "GOVERNISTA", "ABC12345-0"));
			fail("deveria ter lancado excecao:  dni invalido");
		} catch (NullPointerException npe) {
			
		}
	}
	
	@Test
	void testExcecaDniInexistente() {
		try {
			assertEquals(false, this.sc.votarPlenario("PL 1/2018", "GOVERNISTA", "07000000-0"));
			fail("deveria ter lancado excecao:  dni inexistente");
		} catch (NullPointerException npe) {
			
		}
	}
	
}