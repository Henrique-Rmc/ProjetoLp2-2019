package eco;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controllers.PessoaController;
import eco.proposicao.PL;

class PLtest {
	private PessoaController pc1;
	private PL pl1;
	
	@BeforeEach
	void setUp()throws Exception{
		pc1 = new PessoaController();
		pc1.cadastrarPessoa("Plipox Poplx","061444444-0", "RO","trabalho","DEF");
		pc1.cadastraDeputado("061444444-0", "30012019");
	}
	
	
	@Test
	public void testaPLsemCodigo() {
		String interesses = "saude,educacao basica";
		String[] interessesSeparados = interesses.split(",");
		List<String> todosInteresses = new ArrayList<>();
		
		for (String interesse : interessesSeparados) {
			todosInteresses.add(interesse);
		}
	try {
		pl1 = new PL("PL 1/2016","0A1444444-0", 2016, "Institui a semana da nutricao nas escolas",todosInteresses,"http://example.com/semana_saude", true );
		fail("Erro ao cadastrar projeto: dni invalido");
	}catch(IllegalArgumentException iae) {
}
	try {
		pl1 = new PL("PL 1/2016",null, 2016, "Institui a semana da nutricao nas escolas",todosInteresses,"http://example.com/semana_saude", true );
		fail("Erro ao cadastrar projeto: dni invalido");
	}catch(NullPointerException npe) {
}
	
	
	
	}
	
	@Test
	public void testaPLSemEmenta() {
		String interesses = "saude,educacao basica";
		String[] interessesSeparados = interesses.split(",");
		List<String> todosInteresses = new ArrayList<>();
		
		for (String interesse : interessesSeparados) {
			todosInteresses.add(interesse);
		}
		
		try {
			pl1 = new PL("PL 1/2016","061444444-0", 2016, "",todosInteresses,"http://example.com/semana_saude", true );
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		}catch(IllegalArgumentException iae) {
	}
		
		try {
			pl1 = new PL("PL 1/2016","061444444-0", 2016, null ,todosInteresses,"http://example.com/semana_saude", true );
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		}catch(NullPointerException npe) {
	}
	
}
	
	@Test
	public void testaPLSemURL() {
		String interesses = "saude,educacao basica";
		String[] interessesSeparados = interesses.split(",");
		List<String> todosInteresses = new ArrayList<>();
		
		for (String interesse : interessesSeparados) {
			todosInteresses.add(interesse);
		}
		
		try {
			pl1 = new PL("PL 1/2016","061444444-0", 2016, "Institui a semana da nutricao nas escolas",todosInteresses,"", true );
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		}catch(IllegalArgumentException iae) {
	}
		
		try {
			pl1 = new PL("PL 1/2016","061444444-0", 2016, "Institui a semana da nutricao nas escolas" ,todosInteresses,null, true );
			fail("Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		}catch(NullPointerException npe) {
	}
	
}
	
	
}














