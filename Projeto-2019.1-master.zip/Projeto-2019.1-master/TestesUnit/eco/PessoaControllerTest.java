package eco;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controllers.PessoaController;

/**
 * Classe para testes de PessoaController.
 *
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */
class PessoaControllerTest {

	private PessoaController pc;
	private PessoaController pc2;
	private PessoaController pc3;
	private PessoaController pc4;

	@BeforeEach

	void setUp() throws Exception {
		pc = new PessoaController();
		pc2 = new PessoaController();
		pc3 = new PessoaController();
		pc4 = new PessoaController();

		pc.cadastrarPessoa("Marina Maria", "131111111-0", "PB", "educacao,seguranca publica,saude", "WF");
		pc.cadastrarPessoa("Marina", "121111111-0", "PB", "educacao,seguranca publica,saude", "WF");
		pc.cadastrarPessoa("Zaphod Beeblebox", "031444444-0", "RO", "trabalho", "DEF");
	}

	@Test
	void testaNomeVazioEnulo() {
		try {
			pc2.cadastrarPessoa(" ", "011111111-0", "PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: nome nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
		}
		try {
			pc2.cadastrarPessoa(null, "011111111-0", "PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: nome nao pode ser vazio ou nulo");
		} catch (NullPointerException npe) {
		}

	}

	@Test
	void TestaDniVazioInvalidoNulo() {
		try {
			pc2.cadastrarPessoa("Marina Maria", "", "PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni nao pode ser vazio ou nulo");
		} catch (IllegalArgumentException iae) {
		}
		try {
			pc3.cadastrarPessoa("Marina", "A1111111-0", "PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni invalido");
		} catch (IllegalArgumentException iae) {
		}
		try {
			pc4.cadastrarPessoa("Marina", null, "PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni invalido");
		} catch (NullPointerException npe) {
		}
	}

	@Test
	void TestaEstadoVazioOuNulo() {
		try {
			pc3.cadastrarPessoa("Marina", "011111111-0", "", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni invalido");
		} catch (IllegalArgumentException iae) {
		}
		try {
			pc4.cadastrarPessoa("Marina", "011111111-0", null, "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni invalido");
		} catch (NullPointerException npe) {
		}
	}

	@Test
	void testCadastroDniExistente() {
		// Teste com partido
		try {
			pc.cadastrarPessoa("Juliano", "131111111-0", "PB", "educacao", "AB");
			fail("Deveria ter lançado excecao pois tenta cadastrar Dni ja cadastrado");
		} catch (IllegalArgumentException iae) {

		}

		// Teste sem partido
		try {
			pc.cadastrarPessoa("Juliano", "131111111-0", "PB", "educacao");
			fail("Deveria ter lançado excecao pois tenta cadastrar Dni ja cadastrado");
		} catch (IllegalArgumentException iae) {

		}
	}

	@Test
	void testaExibeEcadastraPessoa() {

		pc.cadastrarPessoa("Marina Maria", "031111111-0", "PB", "educacao,seguranca publica,saude");
		assertEquals("Marina Maria - 031111111-0 (PB) - Interesses: educacao,seguranca publica,saude",
				pc.exibePessoa("031111111-0"));
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@Test
	void testDeputadoComDataVazia() {
		try {
			pc.cadastraDeputado("131111111-0", "");
			fail("Deveria ter lancado excecao pois data foi passada vazia");
		} catch (IllegalArgumentException iae) {

		}

		try {
			pc.cadastraDeputado("121111111-0", null);
			fail("Deveria ter lancado excecao pois data foi passada nula");
		} catch (NullPointerException npe) {

		}

	}

	@Test
	void testDeputadoComDataInvalida() {
		try {
			pc.cadastraDeputado("131111111-0", "12478");
			fail("Deveria ter lancado excecao pois data foi passada no formato invalido");
		} catch (IllegalArgumentException iae) {

		}

		try {
			pc.cadastraDeputado("121111111-0", "12/08/2017");
			fail("Deveria ter lancado excecao pois data foi passada no formato invalido");
		} catch (IllegalArgumentException iae) {

		}
	}

	@Test
	void testDeputadoComDataFutura() {

		try {
			pc.cadastraDeputado("131111111-0", "12082019");
			fail("Deveria ter lancado excecao pois foi passada data futura");
		} catch (IllegalArgumentException iae) {

		}

		try {
			pc.cadastraDeputado("121111111-0", "01012020");
			fail("Deveria ter lancado excecao pois foi passada data futura");
		} catch (IllegalArgumentException iae) {

		}

	}

	@Test
	void testDeputadoComPessoaInexistente() {
		try {
			pc.cadastraDeputado("0000011111", "01012019");
			fail("Deveria ter lancado excecao pois nao existe pessoa com esse dni");
		} catch (NullPointerException npe) {

		}
	}
	
	@Test
	void testDeputadoComPessoaSemPartido() {
		pc.cadastrarPessoa("Julia", "000111", "PB", "");
		try {
			pc.cadastraDeputado("000111", "01012019");
			fail("Deveria ter lancado excecao pois nao tem partido nesta pessoa");
		} catch (NullPointerException npe) {

		}
	}

	@Test
	void testExibePessoa() {
		pc.cadastraDeputado("031444444-0", "30012019");

		assertEquals("POL: Zaphod Beeblebox - 031444444-0 (RO) - DEF - Interesses: trabalho - 30/01/2019 - 0 Leis",
				pc.exibePessoa("031444444-0"));
	}
	
	@Test
	void testExibePessoaComPessoaInexistente() {
		try {
			pc.exibePessoa("001010101");
			fail("Deveria ter lancado excecao pois nao existe pessoa com esse dni");
		} catch (NullPointerException npe) {

		}
	}
}