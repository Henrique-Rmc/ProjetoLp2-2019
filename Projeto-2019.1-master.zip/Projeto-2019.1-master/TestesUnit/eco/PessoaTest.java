package eco;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import eco.pessoa.Pessoa;

/**
 * Classe para testes de Pessoa.
 *
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */
class PessoaTest {

	private Pessoa p1;
	private Pessoa p2;
	private Pessoa p3;
	private Pessoa p4;
	
	@BeforeEach
	void setUp() throws Exception {
		p1 = new Pessoa("Marina Maria", "011111111-0","PB", "educacao,seguranca publica,saude");
	}
	@Test
	void testaNomeVazioEnulo() {
		try {
			p2 = new Pessoa(" ", "011111111-0","PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: nome nao pode ser vazio ou nulo");
		}catch(IllegalArgumentException iae) {
	}
		try {
			p2 = new Pessoa(null, "011111111-0","PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: nome nao pode ser vazio ou nulo");
		}catch(NullPointerException npe) {
	}
		
	}
		
	@Test
	void TestaDniVazioInvalidoNulo(){
		try {
			p2 = new Pessoa("Marina Maria","","PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni nao pode ser vazio ou nulo");
		}catch(IllegalArgumentException iae) {
	}
		try {
			p3 = new Pessoa("Marina","A1111111-0","PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni invalido");
		}catch(IllegalArgumentException iae) {
	}
		try {
			p4 = new Pessoa("Marina",null,"PB", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni invalido");
		}catch(NullPointerException npe) {
	}
	}
	
	@Test 
	void TestaEstadoVazioOuNulo() {
		try {
			p3 = new Pessoa("Marina","011111111-0","", "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni invalido");
		}catch(IllegalArgumentException iae) {
	}
		try {
			p4 = new Pessoa("Marina","011111111-0",null, "educacao,seguranca publica,saude");
			fail("Erro ao cadastrar pessoa: dni invalido");
		}catch(NullPointerException npe) {
	}	
	}
	
	@Test
	void testaGetDetalhes() {
		p1 = new Pessoa("Marina Maria", "011111111-0","PB", "educacao,seguranca publica,saude");
		p2 = new Pessoa("Joana" , "001122" , "PB", "   ", "ABC");
		
		assertEquals("Marina Maria - 011111111-0 (PB) - Interesses: educacao,seguranca publica,saude",p1.getDetalhes());
		assertEquals("Joana - 001122 (PB) - ABC",p2.getDetalhes());
		
		p1 = new Pessoa("Marina Maria", "011111111-0","PB", "educacao,seguranca publica,saude", "ABCD");
		assertEquals("Marina Maria - 011111111-0 (PB) - ABCD - Interesses: educacao,seguranca publica,saude",p1.getDetalhes());
	}
	
	@Test
	void testaGetNome() {
		assertEquals("Marina Maria", p1.getNome());
	}
	
	@Test
	void testaGetDni() {
		assertEquals("011111111-0", p1.getDni());
	}
	
	@Test
	void testaGetEstado() {
		assertEquals("PB", p1.getEstado());
	}
	
	@Test
	void testaGetInteresses() {
		List<String> listaTeste = new ArrayList<>();
		listaTeste.add("educacao");
		listaTeste.add("seguranca publica");
		listaTeste.add("saude");
		assertEquals(listaTeste, p1.getInteresses());
	}
	
	@Test
	void testGetPartido() {
		assertEquals("", p1.getPartido());
		p2 = new Pessoa("Joana" , "001122" , "PB", "   ", "ABC");
		assertEquals("ABC", p2.getPartido());
	}
}