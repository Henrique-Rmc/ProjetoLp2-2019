package eco;

import controllers.SystemController;
import easyaccept.EasyAccept;

/**
 * Fachada que promove uma interface simplificada dos diversos controllers do
 * sistema.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */

public class Facade {

	/** Controller do Sistema. */
	private SystemController systemController;

	/**
	 * Constroi um Facade.
	 */
	public Facade() {
		this.systemController = new SystemController();
	}

	public static void main(String[] args) {
		args = new String[] { "eco.Facade", "CasosDeUso/use_case_1.txt", "CasosDeUso/use_case_2.txt",
				"CasosDeUso/use_case_3.txt", "CasosDeUso/use_case_4.txt", "CasosDeUso/use_case_5.txt",
				"CasosDeUso/use_case_6.txt", "CasosDeUso/use_case_7.txt", "CasosDeUso/use_case_8.txt"
				,"CasosDeUso/use_case_9.txt" };
		EasyAccept.main(args);
	}
	
	/**
	 * Metodo que limpa o estado atual do sistema e seus arquivos.
	 */
	public void limparSistema() {
		this.systemController.limparSistema();
	}
	/**
	 * Metodo que salva o estado atual do sistema em arquivos.
	 */
	public void salvarSistema() {
		this.systemController.salvarSistema();
	}
	/**
	 * Metodo que carrega o sistema a partir de arquivos salvos anteriormente. 
	 */
	public void carregarSistema() {
		this.systemController.carregarSistema();
	}

	/**
	 * Cadastra um novo objeto Pessoa a partir do nome, do DNI, do estado e dos
	 * interesses da pessoa.
	 * 
	 * @param nome       o nome da pessoa
	 * @param dni        o DNI da pessoa
	 * @param estado     o estado de localidade da pessoa
	 * @param interesses os interesses da pessoa
	 */
	public void cadastrarPessoa(String nome, String dni, String estado, String interesses) {
		this.systemController.cadastrarPessoa(nome, dni, estado, interesses);
	}

	/**
	 * Cadastra um novo objeto Pessoa a partir do nome, do DNI, do estado, dos
	 * interesses e do partido da pessoa.
	 * 
	 * @param nome       o nome da pessoa
	 * @param dni        o DNI da pessoa
	 * @param estado     o estado de localidade da pessoa
	 * @param interesses os interesses da pessoa
	 * @param partido    o partido da pessoa
	 */
	public void cadastrarPessoa(String nome, String dni, String estado, String interesses, String partido) {
		this.systemController.cadastrarPessoa(nome, dni, estado, interesses, partido);
	}

	/**
	 * Cadastra um Deputado a partir da data de inicio da mandato, passada como
	 * parametro, e adiciona como funcionalidade a pessoa associada ao DNI tambem
	 * passado como parametro.
	 * 
	 * @param dni          o DNI da pessoa
	 * @param dataDeInicio a data de inicio do mandato do deputado
	 */
	public void cadastrarDeputado(String dni, String dataDeInicio) {
		this.systemController.cadastrarDeputado(dni, dataDeInicio);
	}

	/**
	 * Retorna a String que representa a pessoa cadastrada a partir do DNI passado
	 * como parametro.
	 * 
	 * @param dni o DNI da pessoa
	 * @return a representacao em String da pessoa
	 */
	public String exibirPessoa(String dni) {
		return this.systemController.exibirPessoa(dni);
	}

	/**
	 * Cadastra um novo objeto Partido a partir do nome do partido.
	 * 
	 * @param partido o nome do partido
	 */
	public void cadastrarPartido(String partido) {
		this.systemController.cadastrarPartido(partido);
	}

	/**
	 * Retorna a String que representa o conjuto de partidos cadastrados.
	 * 
	 * @return a representacao em String do conjunto de partidos
	 */
	public String exibirBase() {
		return this.systemController.exibirBase();
	}

	/**
	 * Metodo que cadastra uma comissao.
	 * 
	 * @param tema      o tema que a comissao tratara.
	 * @param politicos os politicos que formarao a comissao.
	 */
	public void cadastrarComissao(String tema, String politicos) {
		this.systemController.cadastrarComissao(tema, politicos);
	}

	/**
	 * Metodo que cadastra uma PL.
	 * 
	 * @param dni        o dni do deputado que propos o projeto.
	 * @param ano        o ano de proposicao do projeto.
	 * @param ementa     pequeno resumo do projeto.
	 * @param interesses os interesses relacionados ao projeto.
	 * @param url        o endereco do documento.
	 * @param conclusivo os artigos da constitucao a serem complementados ou
	 *                   emendados.
	 * @return uma String com o codigo da PL.
	 */
	public String cadastrarPL(String dni, int ano, String ementa, String interesses, String url, boolean conclusivo) {
		return this.systemController.cadastrarPL(dni, ano, ementa, interesses, url, conclusivo);
	}

	/**
	 * Metodo responsavel por cadastrar uma PLP
	 * 
	 * @param dni        o dni do deputado que propos o projeto.
	 * @param ano        o ano de proposicao do projeto.
	 * @param ementa     pequeno resumo do projeto.
	 * @param interesses os interesses relacionados ao projeto.
	 * @param url        o endereco do documento.
	 * @param artigos    os artigos da constitucao a serem complementados ou
	 *                   emendados.
	 * @return uma String com o codigo da PLP.
	 */
	public String cadastrarPLP(String dni, int ano, String ementa, String interesses, String url, String artigos) {
		return this.systemController.cadastrarPLP(dni, ano, ementa, interesses, url, artigos);
	}

	/**
	 * Metodo responsavel por cadastar uma PEC.
	 * 
	 * @param dni        o dni do deputado que propos o projeto.
	 * @param ano        o ano de proposicao do projeto.
	 * @param ementa     pequeno resumo do projeto.
	 * @param interesses lista de interesses relacionados ao projeto.
	 * @param url        o endereco do documento.
	 * @param artigos    os artigos da constitucao a serem complementados ou
	 *                   emendados.
	 * @return uma String com o codigo da PEC.
	 */
	public String cadastrarPEC(String dni, int ano, String ementa, String interesses, String url, String artigos) {
		return this.systemController.cadastrarPEC(dni, ano, ementa, interesses, url, artigos);
	}

	/**
	 * Metodo que retorna a representacao de um projeto a partir do seu codigo.
	 * 
	 * @param codigo o codigo do projeto a ser exibido.
	 * @return a representacao em String de um projeto.
	 */
	public String exibirProjeto(String codigo) {
		return this.systemController.exibirProjeto(codigo);
	}

	/**
	 * Metodo responsavel por votar uma proposta em uma comissao.
	 * 
	 * @param codigo           o codigo da proposta a ser votada.
	 * @param statusGovernista String que diz se a proposta é de interesse
	 *                         governista ou nao.
	 * @param proximoLocal     o proximo local que a proposta sera votada.
	 * @return um boolean que indica se a proposta foi aprovada ou nao.
	 */
	public boolean votarComissao(String codigo, String statusGovernista, String proximoLocal) {
		return this.systemController.votarComissao(codigo, statusGovernista, proximoLocal);
	}

	/**
	 * Metodo responsavel por votar uma proposta no plenario.
	 * 
	 * @param codigo           o codigo da proposta a ser votada.
	 * @param statusGovernista String que diz se a proposta é de interesse
	 *                         governista ou nao.
	 * @param presentes        String contendo o dni de todos os deputados presentes
	 *                         na votacao.
	 * @return um boolean que indica se a proposta foi aprovada ou nao.
	 */
	public boolean votarPlenario(String codigo, String statusGovernista, String presentes) {
		return this.systemController.votarPlenario(codigo, statusGovernista, presentes);
	}

	/**
	 * Metodo responsavel por retornar todos os tramites de uma proposta.
	 * 
	 * @param codigo o codigo da proposta.
	 * @return uma String contendo todos os tramites da proposta separados por
	 *         virgula.
	 */
	public String exibirTramitacao(String codigo) {
		return this.systemController.exibirTramitacao(codigo);
	}

	/**
	 * Metodo responsavel por configurar um tipo de estrategia para selecao da
	 * proposta mais relacionada para determinada pessoa.
	 * 
	 * @param dni        o dni da pessoa.
	 * @param estrategia o tipo de estrategia que sera adotada para a pessoa.
	 */
	public void configurarEstrategiaPropostaRelacionada(String dni, String estrategia) {
		this.systemController.configurarEstrategiaPropostaRelacionada(dni, estrategia);
	}

	/**
	 * Metodo responsavel por selecionar e retornar a proposta mais relacionada com
	 * determinada pessoa.
	 * 
	 * @param dni o dni da pessoa.
	 * @return o codigo da proposta selecionada.
	 */
	public String pegarPropostaRelacionada(String dni) {
		return this.systemController.pegarPropostaRelacionada(dni);
	}

}