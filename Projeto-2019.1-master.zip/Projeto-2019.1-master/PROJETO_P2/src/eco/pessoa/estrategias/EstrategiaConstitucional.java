package eco.pessoa.estrategias;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import comparators.OrdenaPorAntiguidade;
import eco.proposicao.ProposicaoLegislativa;

/**
 * Classe que eh o tipo de estrategia de selecao Constitucional.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 1182100688
 * 
 */
public class EstrategiaConstitucional implements EstrategiaPropostaRelacionada, Serializable {

	/**
	 * Retorna o codigo da proposicao mais relacionada, considerando o tipo da
	 * mesma. Sendo priorizadas as proposicoes que alteram constituicao.
	 * 
	 * @param propostas lista contendo as propostas pre-selecionadas a partir dos
	 *                  interesses em comum.
	 * @return o codigo da proposicao mais relacionada.
	 */
	@Override
	public String retornaPropostaRelacionada(List<ProposicaoLegislativa> propostas) {
		if (propostas.size() == 1)
			return propostas.get(0).getCodigo();
		if (propostas.size() == 0)
			return "";

		List<ProposicaoLegislativa> listaPecs = new ArrayList<>();
		List<ProposicaoLegislativa> listaPlps = new ArrayList<>();
		List<ProposicaoLegislativa> listaPls = new ArrayList<>();
		for (ProposicaoLegislativa proposta : propostas) {
			if (proposta.getTipo().equals("PEC")) {
				listaPecs.add(proposta);
			} else if (proposta.getTipo().equals("PLP")) {
				listaPlps.add(proposta);
			} else {
				listaPls.add(proposta);
			}
		}

		if (listaPecs.size() == 1) {
			return listaPecs.get(0).getCodigo();
		} else if (listaPecs.size() == 0) {
			if (listaPlps.size() == 1) {
				return listaPlps.get(0).getCodigo();
			} else if (listaPlps.size() == 0) {
				if (listaPls.size() == 1) {
					return listaPls.get(0).getCodigo();
				}
			}
		}

		if (listaPecs.size() > 1) {
			Collections.sort(listaPecs, new OrdenaPorAntiguidade());
			return listaPecs.get(0).getCodigo();
		} else if (listaPlps.size() > 1) {
			Collections.sort(listaPlps, new OrdenaPorAntiguidade());
			return listaPlps.get(0).getCodigo();
		} else {
			Collections.sort(listaPls, new OrdenaPorAntiguidade());
			return listaPls.get(0).getCodigo();
		}
	}

}