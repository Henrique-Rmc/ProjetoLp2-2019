package eco.pessoa.estrategias;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import comparators.OrdenaPorAntiguidade;
import comparators.OrdenaPorAprovacao;
import eco.proposicao.ProposicaoLegislativa;

/**
 * Classe que eh o tipo de estrategia de selecao Aprovacao.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 1182100688
 * 
 */
public class EstrategiaAprovacao implements EstrategiaPropostaRelacionada, Serializable {

	/**
	 * Retorna o codigo da proposicao mais relacionada, considerando a maior
	 * quantidade de aprovacoes.
	 * 
	 * @param propostas lista contendo as propostas pre-selecionadas a partir dos
	 *                  interesses em comum.
	 * @return o codigo da proposicao mais relacionada.
	 */
	@Override
	public String retornaPropostaRelacionada(List<ProposicaoLegislativa> propostas) {
		if (propostas.size() == 1)
			return propostas.get(0).getCodigo();
		if (propostas.size() == 0)
			return "";

		Collections.sort(propostas, new OrdenaPorAprovacao());
		if (contaAprovacao(propostas.get(0)) != contaAprovacao(propostas.get(1))) {
			return propostas.get(0).getCodigo();
		} else {
			Collections.sort(propostas, new OrdenaPorAntiguidade());
			return propostas.get(0).getCodigo();
		}
	}

	/**
	 * Metodo auxiliar para retornar a quantidade de aprovacoes de determinada proposicao.
	 * @param p o codigo da proposicao.
	 * @return a quantidade de aprovacoes de determinada proposicao.
	 */
	private int contaAprovacao(ProposicaoLegislativa p) {
		int aprovacoes = 0;
		for (String status : p.getTramitacao()) {
			String[] aux = status.split(" ");
			if (aux[0].equals("APROVADO"))
				aprovacoes += 1;
		}
		return aprovacoes;
	}

}
