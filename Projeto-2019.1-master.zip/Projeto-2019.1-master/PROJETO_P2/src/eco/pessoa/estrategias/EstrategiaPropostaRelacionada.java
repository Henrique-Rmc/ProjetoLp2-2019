package eco.pessoa.estrategias;

import java.util.List;

import eco.proposicao.ProposicaoLegislativa;

/**
 * Interface para os tipos de estrategia para selecao de proposta mais relacionada.
 *  
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 1182100688
 * 
 */
public interface EstrategiaPropostaRelacionada {
	
	/**
	 * Retorna o codigo da proposicao mais relacionada.
	 * @param propostas lista contendo as propostas pre-selecionadas a partir dos interesses em comum.
	 * @return o codigo da proposicao mais relacionada.
	 */
	public String retornaPropostaRelacionada(List<ProposicaoLegislativa> propostas);
	
}
