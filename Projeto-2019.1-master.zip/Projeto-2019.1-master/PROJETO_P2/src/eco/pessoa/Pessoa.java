package eco.pessoa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import eco.pessoa.estrategias.EstrategiaConstitucional;
import eco.pessoa.estrategias.EstrategiaPropostaRelacionada;
import eco.proposicao.ProposicaoLegislativa;
import validador.Validador;

/**
 * Representacao de uma pessoa, responsavel por manter o registro do nome, do
 * DNI, do estado, dos interesses, do partido e da funcao.
 *
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */

public class Pessoa  implements Serializable{

	/** O nome da pessoa. */
	private String nome;
	/** O DNI da pessoa. */
	private final String dni;
	/** O estado de localidade da pessoa. */
	private String estado;
	/** Os Interesses da pessoa. */
	private List<String> interesses;
	/** O partido da pessoa. */
	private String partido;
	/** A funcao da pessoa. */
	private Funcao funcao;
	/** Objeto para validar os dados recebidos. */
	private Validador validacao;
	/** Estrategia para escolher proposta relacionada */
	private EstrategiaPropostaRelacionada estrategia;

	/**
	 * Constroi uma pessoa a partir do nome, do DNI, do estado, dos interesses e do
	 * partido.
	 * 
	 * @param nome       o nome da pessoa
	 * @param dni        o DNI da pessoa
	 * @param estado     o estado de localidade da pessoa
	 * @param interesses os interesse da pessoa
	 * @param partido    o partido da pessoa
	 */
	public Pessoa(String nome, String dni, String estado, String interesses, String partido) {
		this.validacao = new Validador();
		this.validacao.validaString(nome, "Erro ao cadastrar pessoa: nome nao pode ser vazio ou nulo");
		this.validacao.validaString(dni, "Erro ao cadastrar pessoa: dni nao pode ser vazio ou nulo");
		this.validacao.validaDni(dni, "Erro ao cadastrar pessoa: dni invalido");
		this.validacao.validaString(estado, "Erro ao cadastrar pessoa: estado nao pode ser vazio ou nulo");

		this.nome = nome;
		this.dni = dni;
		this.estado = estado;
		this.interesses = new ArrayList<>();

		if (interesses != null) {
			if (!interesses.trim().isEmpty()) {
				String[] todosInteresses = interesses.split(",");
				for (String interesse : todosInteresses) {
					this.interesses.add(interesse);
				}
			}
		}

		this.partido = partido;
		this.funcao = new Cidadao();
		this.estrategia = new EstrategiaConstitucional();
	}

	/**
	 * Constroi uma pessoa a partir do nome, do DNI, do estado e dos interesses.
	 * 
	 * @param nome       o nome da pessoa
	 * @param dni        o DNI da pessoa
	 * @param estado     o estado de localidade da pessoa
	 * @param interesses os interesse da pessoa
	 */
	public Pessoa(String nome, String dni, String estado, String interesses) {
		this(nome, dni, estado, interesses, "");
	}

	/**
	 * Retorna a String contendo o nome da pessoa.
	 * 
	 * @return a String contendo o nome da pessoa
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Retorna a String contendo o DNI da pessoa.
	 * 
	 * @return a String contendo o DNI da pessoa
	 */
	public String getDni() {
		return dni;
	}

	/**
	 * Retorna a String contendo o estado da pessoa.
	 * 
	 * @return a String contendo o estado da pessoa
	 */
	public String getEstado() {
		return estado;
	}

	/**
	 * Altera o estado da pessoa pelo novo estado passado como parametro.
	 * 
	 * @param estado o novo estado da pessoa
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}

	/**
	 * Retorna a String contendo os interesses da pessoa.
	 * 
	 * @return a String contendo os interesses da pessoa
	 */
	public List<String> getInteresses() {
		return interesses;
	}

	/**
	 * Retorna a String contendo o partido da pessoa.
	 * 
	 * @return a String contendo o partido da pessoa
	 */
	public String getPartido() {
		return partido;
	}

	/**
	 * Metodo que retorna a funcao de uma pessoa.
	 * 
	 * @return uma String com a funcao da pessoa, podendo ser cidadao ou deputado.
	 */
	public String getFuncao() {
		return funcao.getFuncao();
	}

	/**
	 * Altera a funcao da pessoa pela nova funcao passada como parametro.
	 * 
	 * @param novaFuncao a nova funcao da pessoa.
	 */
	public void setFuncao(Funcao novaFuncao) {
		this.funcao = novaFuncao;
	}

	/**
	 * Altera a estrategia para selecionar proposta pela nova que foi passada por
	 * parametro.
	 * 
	 * @param estrategia a nova estrategia que sera utilizada.
	 */
	public void setEstrategia(EstrategiaPropostaRelacionada estrategia) {
		this.estrategia = estrategia;
	}

	/**
	 * Retorna a String contendo os detalhes da pessoa.
	 * 
	 * @return a String contendo os detalhes da pessoa
	 */
	public String getDetalhes() {
		String detalhesPessoa = "";

		detalhesPessoa += this.nome + " - " + this.dni + " (" + this.estado + ")";

		if (!this.partido.isEmpty())
			detalhesPessoa += " - " + this.partido;
		if (this.interesses.size() > 0) {
			String todosInteresses = "";
			for (int i = 0; i < this.interesses.size() - 1; i++) {
				todosInteresses += interesses.get(i) + ",";
			}
			todosInteresses += interesses.get(this.interesses.size() - 1);
			detalhesPessoa += " - Interesses: " + todosInteresses;
		}
		return funcao.getDetalhes(detalhesPessoa);
	}

	/**
	 * Retorna a proposta mais relacionada com a pessoa, considerando a estrategia
	 * escolhida.
	 * 
	 * @param pls uma lista contendo todas as pls que tem interesses em comum com a
	 *            pessoa.
	 * @return o codigo da proposta que mais se relaciona com a pessoa.
	 */
	public String selecionaPropostaRelacionada(List<ProposicaoLegislativa> pls) {
		return estrategia.retornaPropostaRelacionada(pls);
	}

	/**
	 * Metodo que incrementa o numero de propostas legislativas aprovadas de um
	 * deputado.
	 */
	public void addLeiDeputado() {
		if (this.funcao.getFuncao().equals("Deputado"))
			((Deputado) this.funcao).addNumeroDeLeis();
	}

	/**
	 * Override do metodo hashcode gerado a partir do DNI da pessoa.
	 * 
	 * @return o valor inteiro do codigo hash da pessoa
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		return result;
	}

	/**
	 * Override do metodo equals que retorna um valor booleano True se duas pessoas
	 * forem iguais, na condicao de terem o mesmo DNI, False caso contrario.
	 * 
	 * @return um valor booleano
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pessoa other = (Pessoa) obj;
		if (!dni.equals(other.dni))
			return false;
		return true;
	}

}