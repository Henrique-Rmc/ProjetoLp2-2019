package eco.pessoa;

import java.io.Serializable;

/**
 * Representacao de um cidadao que implementa as funcinalidades da Interface Funcao.
 *  
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 1182100688
 * 
 */

public class Cidadao implements Funcao, Serializable{
	
	/**
	 * Override do metodo getDetalhes da Interface Funcao que retorna a String contendo detalhes da pessoa.
	 * @return a String contendo os detalhes da pessoa.
	 */
	@Override
	public String getDetalhes(String detalhesPessoa) {
		return detalhesPessoa;
	}
	
	/**
	 * Override do metodo getFuncao da Interface Funcao que retorna a String "Cidadao" caso a pessoa seja um cidadao.
	 * @return a String "Cidadao".
	 */
	@Override
	public String getFuncao() {
		return "Cidadao";
	}

}