package eco.pessoa;

/**
 * Interface Funcao que mantem contrato com as classes que implementam as funcionalidades.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */

public interface Funcao {
	
	/** Funcionalidade que retorna a String contendo detalhes da pessoa 
	 * a partir das informacoes passada como parametro.
	 * @param detalhesPessoa as infomarcoes da pessoa
	 * @return a String contendo os detalhes da pessoa
	 */
	public String getDetalhes(String detalhesPessoa);
	
	/**
	 * Funcionalidade que retorna uma String com a funcao da pessoa.
	 * @return uma String com a funcao da pessoa.
	 */
	public String getFuncao();
	
}