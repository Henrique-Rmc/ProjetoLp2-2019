package eco.pessoa;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import validador.Validador;

/**
 * Representacao de um deputado, responsavel por manter o registro da data de inicio do mandato e do numero de leis. 
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */

public class Deputado implements Funcao, Serializable {
	
	/** Data de inicio do mandato. */
	private Date dataDeInicio;
	/** Numero de leis aprovadas do deputado. */
	private int numeroDeLeis;
	/** Objeto para validar os dados recebidos. */
	private Validador validacao;
	
	/**
	 * Constroi um deputado a partir da data de inicio do mandato.
	 * @param dataDeInicio a data de inicio do mandato
	 */
	public Deputado(String dataDeInicio) {
		this.validacao = new Validador();
		this.validacao.validaString(dataDeInicio, "Erro ao cadastrar deputado: data nao pode ser vazio ou nulo");
		this.validacao.validaData(dataDeInicio, "Erro ao cadastrar deputado: data");
		
		SimpleDateFormat formato = new SimpleDateFormat("ddMMyyyy");
		Date data;
		try {
			data = formato.parse(dataDeInicio);
		} catch (ParseException e) {
			throw new IllegalArgumentException("Erro ao cadastrar deputado: data invalida");
		}
		
		this.dataDeInicio = data;
		this.numeroDeLeis = 0;
	}
	
	/**
	 * Retorna a String contendo a data de inicio do mandato no formato DD/MM/AAAA.
	 * @return a data de inicio do mandato formatada
	 */
	public String getDataDeInicio() {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		return df.format(this.dataDeInicio);
	}

	/**
	 * Retorna o valor inteiro do numero de leis aprovadas do deputado.
	 * @return o numero de leis aprovadas
	 */
	public int getNumeroDeLeis() {
		return this.numeroDeLeis;
	}
	
	/** Metodo que incrementa o numero de leis de um Deputado.*/
	public void addNumeroDeLeis() {
		this.numeroDeLeis++;
	}
	
	/**
	 * Retorna a String contendo os detalhes do deputado no formato 
	 * POL: Nome - DNI (Estado) [ - PARTIDO ] [ - Interesses ] - DATA - N Leis.
	 * @return a String contendo os detalhes do deputado
	 */
	@Override
	public String getDetalhes(String detalhesPessoa) {
		return "POL: " + detalhesPessoa + " - " + this.getDataDeInicio() + " - " + this.numeroDeLeis + " Leis";
	}
	
	/**
	 *Override do metodo getFuncao da Interface Funcao que retorna a String "Deputado" caso a pessoa seja um deputado.
	 *@return a String "Deputado".
	 */
	@Override
	public String getFuncao() {
		return "Deputado";
	}

}