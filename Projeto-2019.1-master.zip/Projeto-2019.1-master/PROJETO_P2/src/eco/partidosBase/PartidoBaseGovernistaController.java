package eco.partidosBase;

import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;

import validador.Validador;

/**
 * Controller de Partido, responsavel por controlar e manter o registro do conjunto de partidos da base governista.
 *  
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */

public class PartidoBaseGovernistaController implements Serializable{
	
	/** Conjunto de partidos */
	private Set<String> partidos;
	/** Objeto para validacao dos dados. */
	private Validador validador;
	
	/** Constroi um Controller de partidos. */
	public PartidoBaseGovernistaController() {
		//Para garantir a ordem, foi utilizado TreeSet
		this.partidos = new TreeSet<>();
		this.validador = new Validador();
	}
	
	/**
	 * Cadastra um novo partido a partir do nome.
	 * @param partido o nome do partido
	 */
	public void cadastrarPartido(String partido) {
		validador.validaString(partido, "Erro ao cadastrar partido: partido nao pode ser vazio ou nulo");
		if (this.partidos.contains(partido))
			throw new IllegalArgumentException("Erro ao cadastrar partido: partido ja cadastrado.");
		
		this.partidos.add(partido);
	}
	
	/**
	 * Retorna a String que representa o conjuto de partidos cadastrados.
	 * @return a representacao em String do conjunto de partidos
	 */
	public String exibeBase() {
		String representacao = "";
		int k = 0;
		for (String p : this.partidos) {
			if (k == 0) {
				representacao += p.toString(); k = 1;
			} else {
				representacao += "," + p.toString();
			}
		} return representacao;
	}
	
	/**
	 * Metodo que verifica se um partido faz parte da base governista a partir do nome.
	 * @param partido o nome do partido.
	 * @return um boolean que indica se o partido faz ou não parte da base.
	 */
	public boolean containsPartidoBase(String partido) {
		return this.partidos.contains(partido);
	}
	
}