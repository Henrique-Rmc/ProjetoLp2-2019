package eco.proposicao;

import java.io.Serializable;
import java.util.List;

import validador.Validador;

/**
 * Classe abstrata que representa uma Proposicao que Altera a Constituicao e extende a Proposicao Legislativa.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 *
 */
public abstract class ProposicaoQueAlteraConstituicao extends ProposicaoLegislativa  implements Serializable{
	/**
	 * Os artigos da constitucao a serem complementados ou emendados.
	 */
	private String artigos;
	
	/**
	 * Validador de dados
	 */
	private Validador validador;
	
	/**
	 * Constroi uma Proposicao que Altera a Constituicao a partir do seu codigo, dni, ano, ementa, interesses, url e artigos.
	 * @param codigo o codigo da proposicao.
	 * @param dni o dni do deputado que propos o projeto.
	 * @param ano o ano da proposicao do projeto.
	 * @param ementa pequeno resumo do projeto.
	 * @param interesses lista de interesses relacionados ao projeto.
	 * @param url endereco do documento.
	 * @param artigos os artigos da constitucao a serem complementados ou emendados.
	 */
	public ProposicaoQueAlteraConstituicao(String codigo, String dni, int ano, String ementa, List<String> interesses,
			 String url, String artigos) {
		super(codigo, dni, ano, ementa, interesses, url);
		this.validador = new Validador();
		this.validador.validaString(artigos, "Erro ao cadastrar proposicao: artigo nao pode ser vazio ou nulo");
		this.artigos = artigos;
	}
	
	/**
	 * Metodo abstrato que retorna o tipo da proposicao.
	 * 
	 * @return uma String com o tipo da proposicao.
	 */
	public abstract String getTipo();
	
	/**
	 * Metodo abstrato a ser implementado nas classes especificas que verifica o quorum para votacao de uma proposta.
	 * 
	 * @return um boolean True caso o quorum seja suficiente ou False caso contrario.
	 */
	public abstract boolean verificaQuorum(int deputadosPresentes, int totalDeputados);
	
	/**
	 * Metodo abstrato a ser implementado nas classes especificas que retorna o resultado de uma votacao em plenario.
	 * 
	 * @return um boolean True caso a proposta tenha sido aprovada ou False caso contrario.
	 */
	public abstract boolean resultadoVotacaoPlenario(int deputadosPresentes, String localAtual, int totalDeputados,
			int votosFavoraveis);
	
	/**
	 * Representacao em String de uma Proposicao que Altera a Constituicao.
	 * 
	 * @return uma String com a seguinte formatacao "Codigo - DNI - Ementa - Artigos - Situacao Atual". 
	 */
	@Override
	public String toString() {
		String[] artigos = this.artigos.split(",");
		String saidaArtigos = "";
		for (int i = 0; i < artigos.length - 1; i++) {
			saidaArtigos += artigos[i] + ", ";
		}
		saidaArtigos += artigos[artigos.length - 1];
		String saida = this.getCodigo() + " - " + this.getAutor() + " - " + this.getEmenta() + " - " + saidaArtigos + " - " + this.getSituacaoAtual();
		return saida;
	}
}
