package eco.proposicao;

import java.io.Serializable;
import java.util.List;

/**
 * Representacao de uma PLP que extende a classe ProposicaoQueAlteraConstituicao.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 *
 */
public class PLP extends ProposicaoQueAlteraConstituicao implements Serializable{
	/**
	 * Constroi uma PLP a partir de um codigo, dni, ano, ementa, interesses, url e artigos.
	 * 
	 * @param codigo o codigo da PLP.
	 * @param dni o dni do advogado que propos a PLP.
	 * @param ano o ano de proposicao do projeto.
	 * @param ementa pequena descricao do projeto
	 * @param interesses os interesses relacionados ao projeto.
	 * @param url o endereco do documento.
	 * @param artigos os artigos da constitucao a serem complementados ou emendados.
	 */
	public PLP(String codigo, String dni, int ano, String ementa, List<String> interesses, String url,
			String artigos) {
		super(codigo, dni, ano, ementa, interesses, url, artigos);
	}
	
	/**
	 * Override do metodo getTipo da classe ProposicaoQueAlteraConstituicao que retorna uma String com o tipo de proposta.
	 * @return uma String com a informacao "PLP".
	 */
	@Override
	public String getTipo() {
		return "PLP";
	}
	
	/**
	 * Representacao em String de uma PLP.
	 * @return uma String com a formatacao "Projeto de Lei Complementar - Código - DNI - Ementa - Artigos - Situação".
	 */
	public String toString() {
		return "Projeto de Lei Complementar - " + super.toString();
	}
	
	/**
	 * Override do metodo verificaQuorum que verifica se existe quorum suficiente para se votar uma PLP.
	 * 
	 * @return um boolean False caso o quorum nao seja suficiente e True caso contrario.
	 */
	@Override
	public boolean verificaQuorum(int deputadosPresentes, int totalDeputados) {
		if (deputadosPresentes < Math.floor(totalDeputados / 2) + 1) {
			return false;
		}
		return true;
	}
	
	/**
	 * Override do metodo resultadoVotacaoPlenario que retorna um boolean indicando o resultado de uma votacao de uma
	 * proposta.
	 * 
	 * @return um boolean True caso a proposta tenha sido aprovada e False caso contrario.
	 */
	@Override
	public boolean resultadoVotacaoPlenario(int deputadosPresentes, String localAtual, int totalDeputados,
			int votosFavoraveis) {
		if (votosFavoraveis >= Math.floor(totalDeputados / 2) + 1) {
			if (localAtual.equals("Plenario - 1o turno")) {
				this.removeUltimoTramite();
				this.adicionaTramite("APROVADO (Plenario - 1o turno)");
				this.setSituacaoAtual("EM VOTACAO (Plenario - 2o turno)");
				this.adicionaTramite("EM VOTACAO (Plenario - 2o turno)");
			} else if (localAtual.equals("Plenario - 2o turno")) {
				this.removeUltimoTramite();
				this.adicionaTramite("APROVADO (Plenario - 2o turno)");
				this.setSituacaoAtual("APROVADO");
			}
			return true;
		} else {
			this.removeUltimoTramite();
			if (localAtual.equals("Plenario - 1o turno")) {
				this.adicionaTramite("REJEITADO (Plenario - 1o turno)");
				this.setSituacaoAtual("ARQUIVADO");
			} else if (localAtual.equals("Plenario - 2o turno")) {
				this.adicionaTramite("REJEITADO (Plenario - 2o turno)");
				this.setSituacaoAtual("ARQUIVADO");
			}
			return false;
		}
	}
	
	
}
