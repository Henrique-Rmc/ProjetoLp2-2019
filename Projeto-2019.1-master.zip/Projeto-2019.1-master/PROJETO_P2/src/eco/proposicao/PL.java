package eco.proposicao;

import java.io.Serializable;
import java.util.List;

/**
 * Representacao de uma PL (Projeto de Lei) e extende a classe Proposicao Legislativa.
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 *
 */
public class PL extends ProposicaoLegislativa  implements Serializable{
	
	/**
	 * Atributo especifico de uma PL que indica se uma proposta so precisa ser apreciada nas comissoes e nao precisa ir ao plenario.
	 */
	private boolean conclusivo;
	
	/**
	 * Constroi uma PL a partir do seu codigo, dni, ano, ementa, interesses, url e conclusivo.
	 * @param codigo o codigo da PL.
	 * @param dni o DNI do deputado que propos a lei.
	 * @param ano de proposicao do projeto.
	 * @param ementa descricao do projeto.
	 * @param interesses os interesses relacionados a proposta.
	 * @param url endereco do documento.
	 * @param conclusivo indica se a proposta so precisa ser apreciada nas comissoes e nao precisa ir ao plenario.
	 */
	public PL(String codigo, String dni, int ano, String ementa, List<String> interesses, String url, boolean conclusivo) {
		super(codigo, dni, ano, ementa, interesses, url);
		this.conclusivo = conclusivo;
	}
	
	/**
	 * Metodo que retorna uma String contendo o tipo PL.
	 * 
	 * @return uma String com a informacao "PL".
	 */
	public String getTipo() {
		return "PL";
	}
	/**
	 * Override do metodo conclusivo que retorna um boolean que indica se a proposta só precisa ser apreciada as comissoes, e nao precisa ir ao plenario
	 * .
	 * @return um boolean que indica se a proposta só precisa ser aprecisada nas comissoes, e nao precisa ir ao plenario.
	 */
	
	@Override
	public boolean getConclusivo() {
		return this.conclusivo;
	}
	
	/**
	 * A representacao em String uma uma PL.
	 * 
	 * @return uma String com a formatacao "Projeto de Lei - Código - DNI - Ementa - Conclusivo - Situação".
	 */
	@Override
	public String toString() {
		String saida = "Projeto de Lei - " + this.getCodigo() + " - " + this.getAutor() + " - " + this.getEmenta();
		if (this.conclusivo == true) {
			saida += " - Conclusiva";
		}
		saida += " - " + this.getSituacaoAtual();
		return saida;
	}
	
	/**
	 * Override do metodo verificaQuorum que verifica se existe quorum suficiente para votar uma PL.
	 * 
	 * @return um boolean False caso o quorum nao seja suficiente e True caso contrario.
	 */
	@Override
	public boolean verificaQuorum(int deputadosPresentes, int totalDeputados) {
		if (deputadosPresentes < Math.floor(totalDeputados / 2) + 1) {
			return false;
		}
		return true;
	}
	
	/**
	 * Override do metodo resultadoVotacaoPlenario que retorna um boolean indicando se a proposta foi aprovada ou nao.
	 * 
	 * @return um boolean True caso a proposta tenha sido aprovada e False caso contrario.
	 */
	@Override
	public boolean resultadoVotacaoPlenario(int deputadosPresentes, String localAtual, int totalDeputados,
			int votosFavoraveis) {
		if (votosFavoraveis >= Math.floor(deputadosPresentes / 2) + 1) {
			this.removeUltimoTramite();
			this.adicionaTramite("APROVADO (Plenario)");
			this.setSituacaoAtual("APROVADO");
			return true;
		} else {
			this.removeUltimoTramite();
			this.adicionaTramite("REJEITADO (Plenario)");
			this.setSituacaoAtual("ARQUIVADO");
			return false;
		}
	}

}
