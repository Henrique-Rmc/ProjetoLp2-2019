package eco.proposicao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import validador.Validador;

/**
 * Classe abstrata que representa uma proposicao legislativa generica.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 *
 */
public abstract class ProposicaoLegislativa implements Serializable {
	/**
	 * O DNI do deputado que propos o projeto de lei.
	 */
	private String dni;
	/**
	 * O ano de proposicao do projeto.
	 */
	private int ano;
	/**
	 * o codigo do projeto de lei.
	 */
	private String codigo;
	/**
	 * Pequena descricao do projeto de lei.
	 */
	private String ementa;
	/**
	 * Lista de interesses relacionados ao projeto.
	 */
	private List<String> interesses;
	/**
	 * O status atual do projeto de lei.
	 */
	private String situacaoAtual;
	/**
	 * Lista que contem todos os tramites do projeto.
	 */
	private List<String> tramitacao;
	/**
	 * O endereco do documento.
	 */
	private String url;

	private int quantComissoes;
	/**
	 * Validador de dados.
	 */
	private Validador validador;

	/**
	 * Constroi uma proposicao legislativa a partir do seu codigo, dni do deputado,
	 * ano da proposicao, ementa e lista de interesses.
	 * 
	 * @param codigo     o codigo do projeto.
	 * @param dni        o dni do deputado que propos o projeto.
	 * @param ano        o ano de proposicao do projeto.
	 * @param ementa     um pequeno resumo do projeto de lei.
	 * @param interesses lista de interesses relacionados ao projeto.
	 * @param url        endereco do documento.
	 */
	public ProposicaoLegislativa(String codigo, String dni, int ano, String ementa, List<String> interesses,
			String url) {
		this.validador = new Validador();
		this.validador.validaString(dni, "Erro ao cadastrar proposicao: dni nao pode ser vazio ou nulo");
		this.validador.validaString(ementa, "Erro ao cadastrar proposicao: ementa nao pode ser vazia ou nula");
		this.validador.validaString(url, "Erro ao cadastrar proposicao: url nao pode ser vazia ou nula");
		this.validador.validaDni(dni, "Erro ao cadastrar proposicao: dni invalido");
		this.validador.validaAnoProposicao(ano, "Erro ao cadastrar proposicao: data invalida");
		this.dni = dni;
		this.ano = ano;
		this.codigo = codigo;
		this.ementa = ementa;
		this.interesses = interesses;
		this.situacaoAtual = "EM VOTACAO (CCJC)";
		this.tramitacao = new ArrayList<>();
		this.url = url;
		this.tramitacao.add("EM VOTACAO (CCJC)");
		this.quantComissoes = 0;
	}

	/**
	 * Metodo que retorna o ano de proposicao do projeto.
	 * 
	 * @return um inteiro com o ano de proposicado do projeto.
	 */
	public int getAno() {
		return this.ano;
	}

	/**
	 * Metodo que retorna a situacao atual do projeto.
	 * 
	 * @return uma String com a situacao atual do projeto.
	 */
	public String getSituacaoAtual() {
		return this.situacaoAtual;
	}

	/**
	 * Metodo que altera a situacao atual de um projeto.
	 * 
	 * @param s a nova situacao atual do projeto.
	 */
	public void setSituacaoAtual(String s) {
		this.situacaoAtual = s;
	}

	/**
	 * Metodo que retorna se um projeto e conclusivo ou nao.
	 * 
	 * @return um boolean indicando se o projeto e conclusivo ou nao.
	 */
	public boolean getConclusivo() {
		return false;
	}

	public String getEmenta() {
		return this.ementa;
	}

	/**
	 * Metodo que adiciona um novo tramite a tramitacao do processo.
	 * 
	 * @param t o novo tramite a ser adicionado.
	 */
	public void adicionaTramite(String t) {
		this.tramitacao.add(t);
	}

	/**
	 * Metodo que retorna uma lista de Strings com todos os tramites da tramitacao
	 * do projeto.
	 * 
	 * @return uma lista de Strings com todos os tramites da tramitacao do projeto.
	 */
	public List<String> getTramitacao() {
		return this.tramitacao;
	}

	/**
	 * Metodo que retorna uma lista de Strings com todos os interesses relacionados
	 * ao projeto.
	 * 
	 * @return uma lista de Strings com todos os interesses relacionados ao projeto.
	 */
	public List<String> getInteresses() {
		return this.interesses;
	}

	/**
	 * Metodo que retorna o deputado responsavel pela proposicao do projeto.
	 * 
	 * @return a representacao em String do deputado que propos o projeto.
	 */
	public String getAutor() {
		return this.dni;
	}

	/**
	 * Metodo que retorna do tipo da proposicao legistaliva.
	 * 
	 * @return uma String com o tipo da proposicao.
	 */
	public abstract String getTipo();

	/**
	 * Metodo que remove o ultimo tramite que foi adicionado. Sera usado para
	 * remover pendencia ao realizar votacao.
	 */
	public void removeUltimoTramite() {
		this.tramitacao.remove(this.tramitacao.size() - 1);
	}

	/**
	 * Retorna o codigo da Proposicao.
	 * 
	 * @return o codigo da proposicao.
	 */
	public String getCodigo() {
		return this.codigo;
	}

	/**
	 * Metodo abstrato que verifica se o quorum é suficiente para cada tipo de
	 * proposta legislativa a ser implementado nas classes netas.
	 * 
	 * @param deputadosPresentes os deputados presentes na votacao.
	 * @param totalDeputados     o numero total de deputados.
	 * 
	 * @return um boolean True caso o quorum seja suficiente e False caso contrario.
	 */
	public abstract boolean verificaQuorum(int deputadosPresentes, int totalDeputados);

	/**
	 * Metodo que verifica se um projeto ja foi encerrado.
	 * 
	 * @return um boolean True caso o status do projeto seja ARQUIVADO ou APROVADO e
	 *         False caso contrario.
	 */
	public boolean verificaProjetoEncerrado() {
		if (this.getSituacaoAtual().equals("ARQUIVADO") || this.getSituacaoAtual().equals("APROVADO")) {
			return true;
		}
		return false;
	}

	/**
	 * Metodo que retorna um inteiro com a quantidade de comissoes existentes.
	 * 
	 * @return um inteiro indicando a quantidade de comissoes existentes.
	 */
	public int getQuantComissoes() {
		return this.quantComissoes;
	}

	/**
	 * Override do metodo hashcode a partir do codigo da proposicao legislativa.
	 * 
	 * @return o valor inteiro do codigo hash da proposicao.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	/**
	 * Override do metodo equals que retorna um valor boolean True se duas
	 * proposicoes legislativas forem iguais na condicao de terem o mesmo codigo e
	 * False caso contrario.
	 * 
	 * @return um valor booleano.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProposicaoLegislativa other = (ProposicaoLegislativa) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}

	/**
	 * Metodo abstrato que retorna um boolean indicando o resultado de uma votacao.
	 * 
	 * @param deputadosPresentes o inteiro com o numero de deputados presentes.
	 * @param localAtual o local atual que esta sendo votada a proposta.
	 * @param totalDeputados o inteiro com o numero total de deputados.
	 * @param votosFavoraveis o inteiro com o numero de votos favoraveis a aprovacao da proposta.
	 * @return um boolean True caso a proposta tenha sido aprova ou False caso contrario.
	 */
	public abstract boolean resultadoVotacaoPlenario(int deputadosPresentes, String localAtual, int totalDeputados,
			int votosFavoraveis);
	
	/**
	 * Metodo que registra a votacao em uma comissao.
	 * @param localAtual o local atual que se enconta a proposta.
	 * @param proximoLocal o proximo local de tramite da proposta.
	 * @param resultado o resultado da votacao.
	 */
	public void registraVotacaoComissao(String localAtual, String proximoLocal,
			boolean resultado) {
		
		if (resultado) {
			if (this.getConclusivo()) {
				if (!proximoLocal.equals("plenario")) {
					this.removeUltimoTramite();
					this.adicionaTramite("APROVADO (" + localAtual + ")");
					if (proximoLocal.equals("-")) {
						this.setSituacaoAtual("APROVADO");
					} else {
						this.adicionaTramite("EM VOTACAO (" + proximoLocal + ")");
						this.setSituacaoAtual("EM VOTACAO (" + proximoLocal + ")");
					}
				} else {
					throw new IllegalArgumentException(
							"Erro ao votar proposta: pl conclusiva não pode ter plenario como destino");
				}
			} else {

				if (proximoLocal.equals("plenario")) {
					if (this.getTipo().equals("PL")) {
						proximoLocal = "Plenario";
					} else {
						proximoLocal = "Plenario - 1o turno";
					}
				}
				this.removeUltimoTramite();
				this.adicionaTramite("APROVADO (" + localAtual + ")");
				this.adicionaTramite("EM VOTACAO (" + proximoLocal + ")");
				this.setSituacaoAtual("EM VOTACAO (" + proximoLocal + ")");
			}
			this.quantComissoes++;
		} else {
			if (this.getConclusivo()) {
				if (!proximoLocal.equals("plenario")) {
					this.removeUltimoTramite();
					this.adicionaTramite("REJEITADO (" + localAtual + ")");
					this.setSituacaoAtual("ARQUIVADO");
				} else {
					throw new IllegalArgumentException(
							"Erro ao votar proposta: pl conclusiva não pode ter plenario como destino");
				}
			} else {
				if (proximoLocal.equals("plenario")) {
					this.removeUltimoTramite();
					this.adicionaTramite("REJEITADO (" + localAtual + ")");
					this.adicionaTramite("EM VOTACAO (Plenario)");
					this.setSituacaoAtual("EM VOTACAO (Plenario - 1o turno)");
				} else {
					this.removeUltimoTramite();
					this.adicionaTramite("REJEITADO (" + localAtual + ")");
					this.setSituacaoAtual("EM VOTACAO (" + proximoLocal + ")");
					this.adicionaTramite("EM VOTACAO (" + proximoLocal + ")");
				}
			}
			this.quantComissoes++;
		}
	}

	public int contaInteressesEmComum(List<String> interessesPessoa) {
		int conta = 0;
		for (String interesse : this.interesses) {
			if (interessesPessoa.contains(interesse)) {
				conta++;
			}
		}
		return conta;
	}

}
