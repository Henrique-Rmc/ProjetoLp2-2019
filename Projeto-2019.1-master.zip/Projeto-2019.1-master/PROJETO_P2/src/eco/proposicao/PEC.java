package eco.proposicao;

import java.io.Serializable;
import java.util.List;

/**
 * Representacao de uma PEC que extende a classe
 * ProposicaoQueAlteraConstituicao.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 *
 */
public class PEC extends ProposicaoQueAlteraConstituicao  implements Serializable{

	/**
	 * Constroi uma PEC a partir do seu codigo, dni, ano, ementa, lista de
	 * interesses, url e artigos.
	 * 
	 * @param codigo     o codigo da proposicao.
	 * @param dni        o dni do deputado que propos o projeto.
	 * @param ano        o ano de proposicado do projeto.
	 * @param ementa     um pequeno resumo do projeto.
	 * @param interesses os interesses relacionados a proposta.
	 * @param url        o endereco do documento.
	 * @param artigos    os artigos da constitucao a serem complementados ou
	 *                   emendados.
	 */
	public PEC(String codigo, String dni, int ano, String ementa, List<String> interesses, String url, String artigos) {
		super(codigo, dni, ano, ementa, interesses, url, artigos);
	}

	/**
	 * Retorna a String com o tipo de Proposta Legislativa.
	 * 
	 * @return a String "PEC"
	 */
	public String getTipo() {
		return "PEC";
	}

	/**
	 * A representacao em String de uma proposta legislativa.
	 * 
	 * @return uma String com o formado "Projeto de Emenda Constitucional - Código -
	 *         DNI - Ementa - Artigos - Situação".
	 */
	public String toString() {
		return "Projeto de Emenda Constitucional - " + super.toString();
	}
	
	/**
	 * Override do metodo verificaQuorum que verifica se existe quorum suficiente para votar uma PEC.
	 * @return um boolean True caso o quorum seja suficiente para votar uma PEC e False caso contrario.
	 */
	@Override
	public boolean verificaQuorum(int deputadosPresentes, int totalDeputados) {
		if (deputadosPresentes < Math.floor(totalDeputados * 3 / 5) + 1) {
			return false;
		}
		return true;
	}
	
	/**
	 * Override do metodo resultadoVotacaoPrenario que retorna um boolean caso o projeto tenha sido aprovado ou nao.
	 * @return um boolean True caso o projeto tenha sido aprovado e False caso contrario.
	 */
	@Override
	public boolean resultadoVotacaoPlenario(int deputadosPresentes, String localAtual, int totalDeputados,
			int votosFavoraveis) {
		if (votosFavoraveis >= Math.floor(totalDeputados * 3 / 5) + 1) {
			if (localAtual.equals("Plenario - 1o turno")) {
				this.removeUltimoTramite();
				this.adicionaTramite("APROVADO (Plenario - 1o turno)");
				this.setSituacaoAtual("EM VOTACAO (Plenario - 2o turno)");
				this.adicionaTramite("EM VOTACAO (Plenario - 2o turno)");
			} else if (localAtual.equals("Plenario - 2o turno")) {
				this.removeUltimoTramite();
				this.adicionaTramite("APROVADO (Plenario - 2o turno)");
				this.setSituacaoAtual("APROVADO");
			}
			return true;
		} else {
			this.removeUltimoTramite();
			if (localAtual.equals("Plenario - 1o turno")) {
				this.adicionaTramite("REJEITADO (Plenario - 1o turno)");
				this.setSituacaoAtual("ARQUIVADO");
			} else if (localAtual.equals("Plenario - 2o turno")) {
				this.adicionaTramite("REJEITADO (Plenario - 2o turno)");
				this.setSituacaoAtual("ARQUIVADO");
			}
			return false;
		}
	}

}
