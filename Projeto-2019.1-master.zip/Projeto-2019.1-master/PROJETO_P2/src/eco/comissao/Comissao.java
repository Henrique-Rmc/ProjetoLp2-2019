package eco.comissao;

import java.io.Serializable;
import java.util.List;

import validador.Validador;

/**
 * Representacao de uma Comissao, responsavel por realizar um debate mais
 * profundo sobre as propostas legislativas que tramita pela Camara de
 * Deputados.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 1182100688
 *
 */

public class Comissao implements Serializable {

	/** O tema que a Comissao trata. */
	private String tema;
	/** Lista de politicos que compoem a comissao. */
	private List<String> politicos;
	/** Validacao de dados. */
	private Validador validacao;

	/**
	 * Constroi uma Comissao a partir do tema e dos politicos que a compoem.
	 * 
	 * @param tema      o tema que a Comissao trata.
	 * @param politicos a lista de politicos que compoem a Comissao.
	 */
	public Comissao(String tema, List<String> politicos) {
		this.validacao = new Validador();
		this.validacao.validaString(tema, "Erro ao cadastrar comissao: tema nao pode ser vazio ou nulo");

		this.tema = tema;
		this.politicos = politicos;
	}

	/**
	 * Metodo que retorna o numero de deputados que constituem uma comissao.
	 * 
	 * @return um inteiro com o numero de deputados que constituem uma comissao.
	 */
	public int getQuantidadeDeputados() {
		return this.politicos.size();
	}

	/**
	 * Metodo que retorna uma lista de String com os DNI's dos deputados que
	 * constituem uma comissao.
	 * 
	 * @return uma lista de String com os DNI's dos deputados.
	 */
	public List<String> getPoliticos() {
		return this.politicos;
	}

	/**
	 * Retorna uma String com o tema de interesse da comissao.
	 * 
	 * @return uma String com o tema de interesse da comissao.
	 */
	public String getTema() {
		return tema;
	}

	public boolean resultadoVotacaoComissao(int votosFavoraveis) {

		double resultadoIdeal = Math.floor(this.getQuantidadeDeputados() / 2) + 1;

		if (resultadoIdeal <= votosFavoraveis) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Override do metodo hashcode gerado a partir do tema de interesse da Comissao.
	 * 
	 * @return o valor inteiro do codigo hash da comissao.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tema == null) ? 0 : tema.hashCode());
		return result;
	}

	/**
	 * Override do metodo equals que retorna um valor booleano True se duas
	 * Comissoes forem iguais, na condicao de terem o mesmo tema, False caso
	 * contrario.
	 * 
	 * @return um boolean.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Comissao other = (Comissao) obj;
		if (!tema.equals(other.getTema()))
			return false;
		return true;
	}

}