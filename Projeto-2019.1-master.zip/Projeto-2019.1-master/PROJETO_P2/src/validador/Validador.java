package validador;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Entidade responsavel por validar os dados do sistema.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */

public class Validador  implements Serializable{

	/**
	 * Lanca uma excecao se o valor passado como parametro for null ou vazio. 
	 * 
	 * @param valor o valor a ser validado
	 * @param msg   a mensagem de excecao
	 */
	public void validaString(String valor, String msg) {
		if (valor == null)
			throw new NullPointerException(msg);
		if (valor.trim().equals(""))
			throw new IllegalArgumentException(msg);
	}

	/**
	 * Lanca uma excecao se o dni passado como parametro for composto por algo alem
	 * de numeros e do traco.
	 * 
	 * @param dni o dni a ser validado
	 * @param msg a mensagem de excecao
	 */
	public void validaDni(String dni, String msg) {
		for (int i = 0; i < dni.length(); i++) {
			if (!Character.isDigit(dni.charAt(i)) && dni.charAt(i) != '-') {
				throw new IllegalArgumentException(msg);
			}
		}
	}

	/**
	 * Lanca uma excecao se a data passada como parametro for invalida ou estiver no
	 * tempo futuro.
	 * 
	 * @param valor a data a ser validada
	 * @param msg   a mensagem de excecao
	 */
	public void validaData(String valor, String msg) {
		Date data;
		DateFormat df = new SimpleDateFormat("ddMMyyyy");
		try {
			df.setLenient(false);
			data = df.parse(valor);
		} catch (ParseException ex) {
			throw new IllegalArgumentException(msg + " invalida");
		}

		// Verifica se data é futura
		if (data.compareTo(new Date()) > 0)
			throw new IllegalArgumentException(msg + " futura");
	}
	
	/**
	 * Lanca uma excecao se o ano passado como parametro for invalido, for anterior a 1988 ou posterior ao atual.
	 * @param ano o ano a ser validado.
	 * @param msg a mensagem de excecao.
	 */
	public void validaAnoProposicao(int ano, String msg) {
		if (ano < 1988) {
			throw new IllegalArgumentException(msg + "ano anterior a 1988");
		}
		Date data;
		DateFormat df = new SimpleDateFormat("yyyy");
		try {
			df.setLenient(false);
			data = df.parse(String.valueOf(ano));
		} catch (ParseException ex) {
			throw new IllegalArgumentException(msg + "data invalida");
		}

		if (data.compareTo(new Date()) > 0) {
			throw new IllegalArgumentException(msg + "ano posterior ao ano atual");
		}
	}

	/**
	 * Lanca uma excecao se os DNI's passados como parametro forem compostos por
	 * algo alem de numeros e do traco.
	 * 
	 * @param politicos a lista de DNI's
	 * @param msg       a mensagem de excecao
	 */
	public void validaPoliticos(String[] politicos, String msg) {
		for (String dni : politicos) {
			this.validaDni(dni, msg);
		}
	}
	
	/**
	 * Lanca uma excecao se o status governista for invalido.
	 * 
	 * @param statusGovernista o status a ser verificado.
	 * @param msg a mensagem de excecao.
	 */
	public void validaStatusProjeto(String statusGovernista, String msg) {
		if(!(statusGovernista.equals("GOVERNISTA") ||
			statusGovernista.equals("OPOSICAO") ||
			statusGovernista.equals("LIVRE"))) {
			throw new IllegalArgumentException(msg);
		}
		
	}
	
	/**
	 * Lanca excecao se a estrategia passada for invalida.
	 * @param estrategia a estrategia a ser verificada.
	 * @param msg a mensagem da excecao.
	 */
	public void validaEstrategia(String estrategia, String msg) {
		if(!(estrategia.equals("APROVACAO") ||
				estrategia.equals("CONSTITUCIONAL") ||
				estrategia.equals("CONCLUSAO"))) {
				throw new IllegalArgumentException(msg);
			}
	}
	
	public void validaSeEhPlenario(String localAtual, String msg) {
		if (localAtual.equals("Plenario - 1o turno") || localAtual.equals("Plenario - 2o turno")
				|| localAtual.equals("Plenario")) {
			throw new IllegalArgumentException(msg);
		}
	}

}