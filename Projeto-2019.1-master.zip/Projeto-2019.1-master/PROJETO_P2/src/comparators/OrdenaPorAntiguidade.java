package comparators;

import java.util.Comparator;

import eco.proposicao.ProposicaoLegislativa;

/**
 * Classe que implementa comparator para ProposicaoLegislatica, para ordenar
 * pelo ano de criacao.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */
public class OrdenaPorAntiguidade implements Comparator<ProposicaoLegislativa> {

	/**
	 * Metodo que compara duas Proposicoes, levando em consideracao a antiguidade da
	 * mesma.
	 * 
	 * @return inteiro que representa a ordem.
	 */
	@Override
	public int compare(ProposicaoLegislativa o1, ProposicaoLegislativa o2) {
		if (o1.getAno() < o2.getAno()) {
			return -1;
		} else if (o1.getAno() > o2.getAno()) {
			return 1;
		} else {
			return 0;
		}
	}
}