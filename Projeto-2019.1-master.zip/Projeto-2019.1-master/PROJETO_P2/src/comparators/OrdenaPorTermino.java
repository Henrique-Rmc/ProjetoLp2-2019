package comparators;

import java.util.Comparator;

import eco.proposicao.ProposicaoLegislativa;

/**
 * Classe que implementa comparator para ProposicaoLegislatica, para ordenar
 * pela proximidade da conclusao das votacoes do projeto.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */
public class OrdenaPorTermino implements Comparator<ProposicaoLegislativa> {

	/**
	 * Metodo que compara duas Proposicoes, levando em consideracao a proximidade da
	 * conclusao do projeto.
	 * 
	 * @return inteiro que representa a ordem.
	 */
	@Override
	public int compare(ProposicaoLegislativa o1, ProposicaoLegislativa o2) {
		int prioridadeO1 = this.retornaPrioridade(o1);
		int prioridadeO2 = this.retornaPrioridade(o2);
		
		if (prioridadeO1 < prioridadeO2) {
			return -1;
		}else if(prioridadeO1 > prioridadeO2){
			return 1;
		}else if (o1.getQuantComissoes() > o2.getQuantComissoes()) {
			return -1;
		} else if (o1.getQuantComissoes() < o1.getQuantComissoes()) {
			return 1;
		} else {
			return 0;
		}
	}
	
	private int retornaPrioridade(ProposicaoLegislativa pl) {
		if (pl.getSituacaoAtual().equals("EM VOTACAO (Plenario)")) {
			return 0;
		}
		if (pl.getSituacaoAtual().equals("EM VOTACAO (Plenario - 2o turno)")) {
			return 1;
		}
		if (pl.getSituacaoAtual().equals("EM VOTACAO (Plenario - 1o turno)")) {
			return 2;
		}else {
			return 3;
		}
	}

}