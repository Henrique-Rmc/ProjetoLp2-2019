package comparators;

import java.util.Comparator;

import eco.proposicao.ProposicaoLegislativa;

/**
 * Classe que implementa comparator para ProposicaoLegislatica, para ordenar
 * pela quantidade de aprovacoes em seus tramites.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */
public class OrdenaPorAprovacao implements Comparator<ProposicaoLegislativa> {

	/**
	 * Metodo que compara duas Proposicoes, levando em consideracao a quantidade de
	 * aprovacoes.
	 * 
	 * @return inteiro que representa a ordem.
	 */
	@Override
	public int compare(ProposicaoLegislativa o1, ProposicaoLegislativa o2) {
		if (this.contaAprovacao(o1) < this.contaAprovacao(o2)) {
			return 1;
		} else if (this.contaAprovacao(o1) > this.contaAprovacao(o2)) {
			return -1;
		}
		return 0;
	}

	/**
	 * Metodo auxiliar que conta quantos "APROVADOS" a proposicao contem.
	 * 
	 * @param p a proposicao.
	 * @return inteiro que representa a quantidade de aprovacoes nos tramites.
	 */
	private int contaAprovacao(ProposicaoLegislativa p) {
		int aprovacoes = 0;
		for (String status : p.getTramitacao()) {
			String[] aux = status.split(" ");
			if (aux[0].equals("APROVADO"))
				aprovacoes += 1;
		}
		return aprovacoes;
	}

}