package comparators;

import java.util.Comparator;
import java.util.List;

import eco.proposicao.ProposicaoLegislativa;

/**
 * Classe que implementa comparator para ProposicaoLegislatica, para ordenar
 * pelos interesses.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 *
 */
public class OrdenaPorInteresses implements Comparator<ProposicaoLegislativa>{
	
	private List<String> interessesPessoa;
	
	public OrdenaPorInteresses(List<String> interessesPessoa) {
		this.interessesPessoa = interessesPessoa;
	}
	/**
	 * Metodo que compara duas Proposicoes, levando em consideracao seus interesses.
	 * 
	 * @return inteiro que representa a ordem.
	 */
	@Override
	public int compare(ProposicaoLegislativa o1, ProposicaoLegislativa o2) {
		if (o1.contaInteressesEmComum(interessesPessoa) < o2.contaInteressesEmComum(interessesPessoa)) {
			return -1;
		}else if (o1.contaInteressesEmComum(interessesPessoa) > o2.contaInteressesEmComum(interessesPessoa)) {
			return 1;
		}
		return 0;
	}

}
