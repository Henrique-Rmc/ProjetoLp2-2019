package controllers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import eco.comissao.Comissao;
import validador.Validador;

/**
 * Controller de Comissao, responsavel por controlar e manter o registro do
 * conjunto de comissoes.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */

public class ComissaoController implements Serializable {

	/** Mapa contendo o nome como chave e o objeto Comissao como valor. */
	private Map<String, Comissao> comissoes;
	/** Objeto para validacao dos dados. */
	private Validador validacao;

	/** Constroi um Controller de Comissao. */
	public ComissaoController() {
		this.comissoes = new HashMap<>();
		this.validacao = new Validador();
	}

	/**
	 * Retorna um valor booleano True se o objeto Comissao existir, False caso
	 * contrario.
	 * 
	 * @param tema o nome da comissao
	 * @return o valor booleano
	 */
	public boolean existeComissao(String tema) {
		return comissoes.containsKey(tema);
	}

	/**
	 * Cadastra um novo objeto Comissao a partir do nome da lista de DNI's dos
	 * deputados.
	 * 
	 * @param tema      o nome da Comissao
	 * @param politicos a lista de DNI's dos deputados
	 */
	public void cadastrarComissao(String tema, String[] politicos) {
		this.validacao.validaString(tema, "Erro ao cadastrar comissao: tema nao pode ser vazio ou nulo");

		List<String> todosPoliticos = new ArrayList<>();
		for (String pol : politicos) {
			todosPoliticos.add(pol);
		}

		this.comissoes.put(tema, new Comissao(tema, todosPoliticos));
	}

	/**
	 * Metodo que retorna uma lista de Strings contendo o nome de todos os politicos
	 * que fazem parte de uma comissao.
	 * 
	 * @param tema o nome da comissao.
	 * @return uma lista com o nome dos politicos que fazem parte de uma comissao.
	 */
	public List<String> getPoliticosComissao(String tema) {
		return this.comissoes.get(tema).getPoliticos();
	}

	/**
	 * Metodo que retorna a quantidade de Deputados que compoem uma comissao.
	 * 
	 * @param tema o nome da comissao.
	 * @return um inteiro com o numero de deputados que compoem uma comissao.
	 */
	public int getQuantidadeDeputados(String tema) {
		return this.comissoes.get(tema).getQuantidadeDeputados();
	}

	/**
	 * Metodo que retorna o resultado de uma votacao em uma comissao.
	 * @param localAtual o local atual que se encontra a proposta a ser votada.
	 * @param votosFavoraveis a quantidade de votos favoraveis a aprovacao da proposta.
	 * @return um boolean True indicando se a proposta foi aprovada ou False caso contrario.
	 */
	public boolean resultadoVotacaoComissao(String localAtual, int votosFavoraveis) {
		return this.comissoes.get(localAtual).resultadoVotacaoComissao(votosFavoraveis);
	}

}