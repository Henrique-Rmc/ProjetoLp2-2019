package controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import comparators.OrdenaPorInteresses;
import eco.partidosBase.PartidoBaseGovernistaController;
import eco.pessoa.estrategias.EstrategiaAprovacao;
import eco.pessoa.estrategias.EstrategiaConclusao;
import eco.pessoa.estrategias.EstrategiaConstitucional;
import eco.proposicao.ProposicaoLegislativa;
import validador.Validador;

/**
 * Representacao do controlador do sistema com todos os controladores das
 * classes mais internas.
 *
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 *
 */

public class SystemController {

	/** Controlador de pessoa. */
	private PessoaController pessoaController;
	/** Controlador de partido. */
	private PartidoBaseGovernistaController partidoController;
	/** Controlador de comissao. */
	private ComissaoController comissaoController;
	/** Controlador de proposicao. */
	private ProposicaoController proposicaoController;
	/** Validador de dados. */
	private Validador validacao;

	/** Constroi um controlador do sistema. */
	public SystemController() {
		this.pessoaController = new PessoaController();
		this.partidoController = new PartidoBaseGovernistaController();
		this.comissaoController = new ComissaoController();
		this.proposicaoController = new ProposicaoController();
		this.validacao = new Validador();
	}

	/**
	 * Cadastra um novo objeto Pessoa a partir do nome, do DNI, do estado e dos
	 * interesses da pessoa.
	 * 
	 * @param nome       o nome da pessoa
	 * @param dni        o DNI da pessoa
	 * @param estado     o estado de localidade da pessoa
	 * @param interesses os interesses da pessoa
	 */
	public void cadastrarPessoa(String nome, String dni, String estado, String interesses) {
		this.pessoaController.cadastrarPessoa(nome, dni, estado, interesses);
	}

	/**
	 * Cadastra um novo objeto Pessoa a partir do nome, do DNI, do estado, dos
	 * interesses e do partido da pessoa.
	 * 
	 * @param nome       o nome da pessoa
	 * @param dni        o DNI da pessoa
	 * @param estado     o estado de localidade da pessoa
	 * @param interesses os interesses da pessoa
	 * @param partido    o partido da pessoa
	 */
	public void cadastrarPessoa(String nome, String dni, String estado, String interesses, String partido) {
		this.pessoaController.cadastrarPessoa(nome, dni, estado, interesses, partido);
	}

	/**
	 * Retorna a String que representa a pessoa cadastrada a partir do DNI passado
	 * como parametro.
	 * 
	 * @param dni o DNI da pessoa
	 * @return a representacao em String da pessoa
	 */
	public String exibirPessoa(String dni) {
		return this.pessoaController.exibePessoa(dni);
	}

	/**
	 * Cadastra um Deputado a partir da data de inicio da mandato, passada como
	 * parametro, e adiciona como funcionalidade a pessoa associada ao DNI tambem
	 * passado como parametro.
	 * 
	 * @param dni          o DNI da pessoa
	 * @param dataDeInicio a data de inicio do mandato do deputado
	 */
	public void cadastrarDeputado(String dni, String dataDeInicio) {
		this.pessoaController.cadastraDeputado(dni, dataDeInicio);
	}

	/**
	 * Cadastra um novo objeto Partido a partir do nome do partido.
	 * 
	 * @param partido o nome do partido
	 */
	public void cadastrarPartido(String partido) {
		this.partidoController.cadastrarPartido(partido);
	}

	/**
	 * Retorna a String que representa o conjuto de partidos cadastrados.
	 * 
	 * @return a representacao em String do conjunto de partidos
	 */
	public String exibirBase() {
		return this.partidoController.exibeBase();
	}

	/**
	 * Metodo responsavel por cadastrar uma comissao no sistema a partir do seu tema
	 * e politicos.
	 * 
	 * @param tema      o tema que a comissao tratara.
	 * @param politicos nome dos politicos que formarao a comissao.
	 */
	public void cadastrarComissao(String tema, String politicos) {
		this.validacao.validaString(tema, "Erro ao cadastrar comissao: tema nao pode ser vazio ou nulo");
		this.validacao.validaString(politicos,
				"Erro ao cadastrar comissao: lista de politicos nao pode ser vazio ou nulo");
		if (comissaoController.existeComissao(tema))
			throw new IllegalArgumentException("Erro ao cadastrar comissao: tema existente");

		String[] todosPoliticos = politicos.split(",");
		this.validacao.validaPoliticos(todosPoliticos, "Erro ao cadastrar comissao: dni invalido");
		for (String politico : todosPoliticos) {
			if (!pessoaController.existePessoa(politico))
				throw new NullPointerException("Erro ao cadastrar comissao: pessoa inexistente");
			if (!"Deputado".equals(pessoaController.exibeFuncao(politico)))
				throw new IllegalArgumentException("Erro ao cadastrar comissao: pessoa nao eh deputado");
		}

		this.comissaoController.cadastrarComissao(tema, todosPoliticos);
	}

	/**
	 * Metodo responsavel por cadastrar uma PL.
	 * 
	 * @param dni        o dni do deputado que propos o projeto.
	 * @param ano        o ano de proposicao do projeto.
	 * @param ementa     pequeno resumo do projeto.
	 * @param interesses os interesses relacionados ao projeto.
	 * @param url        o endereco do documento.
	 * @param conclusivo indica se a proposta so precisa ser apreciada nas comissoes
	 *                   e nao precisa ir ao plenario.
	 * @return uma String com o codigo da PL
	 */
	public String cadastrarPL(String dni, int ano, String ementa, String interesses, String url, boolean conclusivo) {
		this.validacao.validaString(dni, "Erro ao cadastrar projeto: autor nao pode ser vazio ou nulo");
		this.validacao.validaString(ementa, "Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		this.validacao.validaString(url, "Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		this.validacao.validaDni(dni, "Erro ao cadastrar projeto: dni invalido");
		if (!pessoaController.existePessoa(dni))
			throw new NullPointerException("Erro ao cadastrar projeto: pessoa inexistente");
		if (!"Deputado".equals(pessoaController.exibeFuncao(dni)))
			throw new IllegalArgumentException("Erro ao cadastrar projeto: pessoa nao eh deputado");
		this.validacao.validaAnoProposicao(ano, "Erro ao cadastrar projeto: ");

		return this.proposicaoController.cadastrarPL(dni, ano, ementa, interesses, url, conclusivo);
	}

	/**
	 * Metodo responsavel por cadastrar uma PLP.
	 * 
	 * @param dni        o dni do deputado que propos o projeto.
	 * @param ano        o ano de proposicao do projeto.
	 * @param ementa     pequeno resumo do projeto.
	 * @param interesses os interesses relacionados ao projeto.
	 * @param url        o endereco do documento.
	 * @param artigos    os artigos da constitucao a serem complementados ou
	 *                   emendados.
	 * @return uma String com o codigo da PLP.
	 */
	public String cadastrarPLP(String dni, int ano, String ementa, String interesses, String url, String artigos) {
		this.validacao.validaString(dni, "Erro ao cadastrar projeto: autor nao pode ser vazio ou nulo");
		this.validacao.validaString(ementa, "Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		this.validacao.validaString(artigos, "Erro ao cadastrar projeto: artigo nao pode ser vazio ou nulo");
		this.validacao.validaString(url, "Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		this.validacao.validaDni(dni, "Erro ao cadastrar projeto: dni invalido");
		if (!pessoaController.existePessoa(dni))
			throw new NullPointerException("Erro ao cadastrar projeto: pessoa inexistente");
		if (!"Deputado".equals(pessoaController.exibeFuncao(dni)))
			throw new IllegalArgumentException("Erro ao cadastrar projeto: pessoa nao eh deputado");
		this.validacao.validaAnoProposicao(ano, "Erro ao cadastrar projeto: ");

		return this.proposicaoController.cadastrarPLP(dni, ano, ementa, interesses, url, artigos);
	}

	/**
	 * Metodo responsavel por cadastrar uma PEC.
	 * 
	 * @param dni        o dni do deputado que propos o projeto.
	 * @param ano        o ano de proposicao do projeto.
	 * @param ementa     pequeno resumo do projeto.
	 * @param interesses os interesses relacionados ao projeto.
	 * @param url        o endereco do documento.
	 * @param artigos    os artigos da constitucao a serem complementados ou
	 *                   emendados.
	 * @return uma String com o codigo da PEC.
	 */
	public String cadastrarPEC(String dni, int ano, String ementa, String interesses, String url, String artigos) {
		this.validacao.validaString(dni, "Erro ao cadastrar projeto: autor nao pode ser vazio ou nulo");
		this.validacao.validaString(ementa, "Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		this.validacao.validaString(artigos, "Erro ao cadastrar projeto: artigo nao pode ser vazio ou nulo");
		this.validacao.validaString(url, "Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		this.validacao.validaDni(dni, "Erro ao cadastrar projeto: dni invalido");
		if (!pessoaController.existePessoa(dni))
			throw new NullPointerException("Erro ao cadastrar projeto: pessoa inexistente");
		if (!"Deputado".equals(pessoaController.exibeFuncao(dni)))
			throw new IllegalArgumentException("Erro ao cadastrar projeto: pessoa nao eh deputado");
		this.validacao.validaAnoProposicao(ano, "Erro ao cadastrar projeto: ");

		return this.proposicaoController.cadastrarPEC(dni, ano, ementa, interesses, url, artigos);
	}

	/**
	 * Metodo que retorna a representacao em String de um projeto a partir do seu
	 * codigo.
	 * 
	 * @param codigo o codigo do projeto a ser exibido.
	 * @return a representacao em String de um projeto.
	 */
	public String exibirProjeto(String codigo) {
		return this.proposicaoController.exibirProjeto(codigo);
	}

	/**
	 * Metodo responsavel por votar um projeto em uma comissao.
	 * 
	 * @param codigo           o codigo do projeto a ser votado.
	 * @param statusGovernista String que diz se a proposta é de interesse
	 *                         governista ou nao.
	 * @param proximoLocal     o proximo local de votacao.
	 * @return um boolean que indica se a proposta foi aprovada ou nao.
	 */
	public boolean votarComissao(String codigo, String statusGovernista, String proximoLocal) {
		this.validacao.validaString(codigo, "Erro ao votar proposta: codigo nao pode ser vazio ou nulo");
		this.validacao.validaString(statusGovernista,
				"Erro ao votar proposta: status governista nao pode ser vazio ou nulo");
		this.validacao.validaString(proximoLocal, "Erro ao votar proposta: proximo local vazio");
		this.validacao.validaStatusProjeto(statusGovernista, "Erro ao votar proposta: status invalido");
		if (!proposicaoController.containsProjeto(codigo))
			throw new NullPointerException("Erro ao votar proposta: projeto inexistente");
		this.proposicaoController.verificaProjetoEncerrado(codigo);

		String[] situacaoSeparada = proposicaoController.getSituacao(codigo).split(" \\(");
		String localAtual = situacaoSeparada[1].replace(")", "");
		this.validacao.validaSeEhPlenario(localAtual, "Erro ao votar proposta: proposta encaminhada ao plenario");

		if (!comissaoController.existeComissao(localAtual))
			throw new NullPointerException(String.format("Erro ao votar proposta: %s nao cadastrada", localAtual));

		List<String> deputadosComissao = comissaoController.getPoliticosComissao(localAtual);
		int votosFavoraveis = this.contaVotos(codigo, deputadosComissao, statusGovernista);
		boolean resultadoVotacao = this.comissaoController.resultadoVotacaoComissao(localAtual, votosFavoraveis);

		this.proposicaoController.registraVotacaoComissao(codigo, localAtual, proximoLocal, resultadoVotacao);
		if (this.proposicaoController.getSituacao(codigo).equals("APROVADO")) {
			this.pessoaController.addLeiDeputado(this.proposicaoController.getAutor(codigo));
		}

		return resultadoVotacao;
	}

	/**
	 * Metodo que verifica se existem interesses em comum entre um projeto e um
	 * politico.
	 * 
	 * @param interessesPl     os interesses relacionados a uma proposta.
	 * @param interessesPessoa os interesses de uma pessoa.
	 * @return um boolean que indica se existem ou nao interesses em comum.
	 */
	private boolean verificaInteressesEmComum(List<String> interessesPl, List<String> interessesPessoa) {
		for (String interesse : interessesPessoa) {
			if (interessesPl.contains(interesse))
				return true;
		}
		return false;
	}

	/**
	 * Metodo que realiza a votacao de uma proposta em Plenario.
	 * 
	 * @param codigo           o codigo da proposta a ser votada.
	 * @param statusGovernista o status da proposta em relacao a ser governista.
	 * @param presentes        uma string com o dni dos deputados presentes.
	 * @return um boolean True caso a proposta tenha sido votada e aprovada, False
	 *         caso contrario.
	 */
	public boolean votarPlenario(String codigo, String statusGovernista, String presentes) {
		this.validacao.validaString(codigo, "Erro ao votar proposta: codigo nao pode ser vazio ou nulo");
		this.validacao.validaString(statusGovernista,
				"Erro ao votar proposta: status governista nao pode ser vazio ou nulo");
		this.validacao.validaString(presentes, "Erro ao votar proposta: presentes vazio");
		this.proposicaoController.verificaProjetoEncerrado(codigo);
		String[] deputadosPresentes = presentes.split(",");
		List<String> deputados = new ArrayList<>();
		for (String dep : deputadosPresentes) {
			deputados.add(dep);
		}
		this.validaDeputadosPresentes(deputadosPresentes, statusGovernista, codigo);
		int totalDeputados = this.pessoaController.contaDeputados();
		int quantDeputadosPresentes = deputadosPresentes.length;
		this.proposicaoController.verificaQuorum(codigo, quantDeputadosPresentes, totalDeputados);

		String[] situacaoSeparada = proposicaoController.getSituacao(codigo).split(" \\(");
		String localAtual = situacaoSeparada[1].replace(")", "");
		if (this.comissaoController.existeComissao(localAtual))
			throw new IllegalArgumentException("Erro ao votar proposta: tramitacao em comissao");

		int votosFavoraveis = this.contaVotos(codigo, deputados, statusGovernista);
		if (this.proposicaoController.resultadoVotacaoPlenario(codigo, quantDeputadosPresentes, localAtual,
				totalDeputados, votosFavoraveis)) {
			if (this.proposicaoController.getSituacao(codigo).equals("APROVADO")) {
				String autor = this.proposicaoController.getAutor(codigo);
				this.pessoaController.addLeiDeputado(autor);
			}
			return true;
		}
		return false;
	}

	/**
	 * Metodo para validar informacoes sobre deputados presentes, status do projeto
	 * e codigo do projeto, para a votacao no plenario.
	 * 
	 * @param deputadosPresentes um array contendo os dni dos deputados presentes.
	 * @param statusGovernista   o status da proposta em relacao a ser governista.
	 * @param codigo             o codigo da proposta.
	 */
	private void validaDeputadosPresentes(String[] deputadosPresentes, String statusGovernista, String codigo) {
		for (String dep : deputadosPresentes) {
			this.validacao.validaDni(dep, "Erro ao votar proposta: dni invalido");
		}
		this.validacao.validaStatusProjeto(statusGovernista, "Erro ao votar proposta: status invalido");
		if (!proposicaoController.containsProjeto(codigo)) {
			throw new NullPointerException("Erro ao votar proposta: projeto inexistente");
		}
		for (String dep : deputadosPresentes) {
			if (!pessoaController.existePessoa(dep)) {
				throw new NullPointerException("Erro ao votar proposta: dni inexistente");
			} else if (!pessoaController.exibeFuncao(dep).equals("Deputado")) {
				throw new IllegalArgumentException("Erro ao votar proposta: pessoa nao eh deputado");
			}
		}
	}

	/**
	 * Metodo que faz e retorna a contagem de votos, leva em consideracao o status
	 * da proposta, e se for livre, os interesses em comum do deputado com a
	 * proposta.
	 * 
	 * @param codigo           o codigo da proposta.
	 * @param deputados        array contendo os dni dos deputados.
	 * @param statusGovernista o status do projeto.
	 * @return inteiro informando a quantidade de votos favoraveis.
	 */
	private int contaVotos(String codigo, List<String> deputados, String statusGovernista) {
		int votosFavoraveis = 0;
		for (String dep : deputados) {
			String partidoPolitico = pessoaController.getPartido(dep);
			if (statusGovernista.equals("GOVERNISTA") && partidoController.containsPartidoBase(partidoPolitico)) {
				votosFavoraveis++;
			} else if (statusGovernista.equals("OPOSICAO") && !partidoController.containsPartidoBase(partidoPolitico)) {
				votosFavoraveis++;
			} else if (statusGovernista.equals("LIVRE")) {
				List<String> interessesPl = proposicaoController.getInteresses(codigo);
				List<String> interessesPolitico = pessoaController.getInteresses(dep);
				if (this.verificaInteressesEmComum(interessesPl, interessesPolitico))
					votosFavoraveis++;
			}
		}
		return votosFavoraveis;
	}

	/**
	 * Metodo que exibe a tramitacao de um projeto.
	 * 
	 * @param codigo o codigo do projeto que se deseja exibir.
	 * @return uma String com toda a tramitacao do projeto.
	 */
	public String exibirTramitacao(String codigo) {
		this.validacao.validaString(codigo, "Erro ao exibir tramitacao: codigo vazio ou nulo");
		if (!this.proposicaoController.containsProjeto(codigo))
			throw new NullPointerException("Erro ao exibir tramitacao: projeto inexistente");

		List<String> todosTramites = this.proposicaoController.getTramitacao(codigo);
		String saida = "";
		for (int i = 0; i < todosTramites.size() - 1; i++) {
			saida += todosTramites.get(i) + ", ";
		}
		saida += todosTramites.get(todosTramites.size() - 1);
		return saida;
	}

	/**
	 * Metodo que altera a estrategia de busca de propostas relacionadas com uma
	 * pessoa de acordo com a sua proximidade com a constituicao, maior proximidade
	 * de conclusao ou maior aprovacao.
	 * 
	 * @param dni        o dni da pessoa.
	 * @param estrategia a estrategia a ser selecionada.
	 */
	public void configurarEstrategiaPropostaRelacionada(String dni, String estrategia) {
		validacao.validaString(dni, "Erro ao configurar estrategia: pessoa nao pode ser vazia ou nula");
		validacao.validaDni(dni, "Erro ao configurar estrategia: dni invalido");
		validacao.validaString(estrategia, "Erro ao configurar estrategia: estrategia vazia");
		validacao.validaEstrategia(estrategia, "Erro ao configurar estrategia: estrategia invalida");
		if (!pessoaController.existePessoa(dni))
			throw new NullPointerException("Erro ao configurar estrategia: pessoa inexistente");

		if ("APROVACAO".equals(estrategia)) {
			this.pessoaController.setEstrategia(dni, new EstrategiaAprovacao());
		} else if ("CONCLUSAO".equals(estrategia)) {
			this.pessoaController.setEstrategia(dni, new EstrategiaConclusao());
		} else {
			this.pessoaController.setEstrategia(dni, new EstrategiaConstitucional());
		}
	}

	/**
	 * Metodo que retorna o codigo da proposta mais relacionada a pessoa de acordo
	 * com o criterio estabelecido.
	 * 
	 * @param dni o dni da pessoa.
	 * @return o codigo da proposta mais relacionada a pessoa.
	 */
	public String pegarPropostaRelacionada(String dni) {
		validacao.validaString(dni, "Erro ao pegar proposta relacionada: pessoa nao pode ser vazia ou nula");
		validacao.validaDni(dni, "Erro ao pegar proposta relacionada: dni invalido");

		List<String> interessesPessoa = pessoaController.getInteresses(dni);
		List<ProposicaoLegislativa> plSelecionadas = proposicaoController
				.selecionaProposicoesComMesmoInteresse(interessesPessoa);
		if (plSelecionadas.size() == 1)
			return plSelecionadas.get(0).getCodigo();
		if (plSelecionadas.size() == 0)
			return "";

		// Ordenar pela quantidade de interesses em comum
		Collections.sort(plSelecionadas, new OrdenaPorInteresses(interessesPessoa));

		if (plSelecionadas.get(0).contaInteressesEmComum(interessesPessoa) != plSelecionadas.get(1)
				.contaInteressesEmComum(interessesPessoa)) {
			return plSelecionadas.get(0).getCodigo();
		}

		return pessoaController.selecionaPropostaRelacionada(dni, plSelecionadas);
	}

	/**
	 * Metodo que salva o estado atual do sistema em arquivos.
	 */
	public void salvarSistema() {
		File f = new File("arquivos");
		remover(f);
		new File("arquivos").mkdir();
		File file = new File("arquivos" + File.separator + "comissoes.dat");
		File file1 = new File("arquivos" + File.separator + "pessoas.dat");
		File file2 = new File("arquivos" + File.separator + "partidos.dat");
		File file3 = new File("arquivos" + File.separator + "proposicoes.dat");
		try {
			file.createNewFile();
			file1.createNewFile();
			file2.createNewFile();
			file3.createNewFile();
		} catch (IOException e1) {

		}
		try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
			ObjectOutputStream out1 = new ObjectOutputStream(new FileOutputStream(file1));
			ObjectOutputStream out2 = new ObjectOutputStream(new FileOutputStream(file2));
			ObjectOutputStream out3 = new ObjectOutputStream(new FileOutputStream(file3));
			out.writeObject(comissaoController);
			out1.writeObject(pessoaController);
			out2.writeObject(partidoController);
			out3.writeObject(proposicaoController);
			out.close();
			out1.close();
			out2.close();
			out3.close();
		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		}

	}

	/**
	 * Metodo que limpa o estado atual do sistema e seus arquivos.
	 */
	public void limparSistema() {
		File f = new File("arquivos");
		remover(f);
		this.pessoaController = new PessoaController();
		this.partidoController = new PartidoBaseGovernistaController();
		this.comissaoController = new ComissaoController();
		this.proposicaoController = new ProposicaoController();
		this.validacao = new Validador();
	}

	public void remover(File f) {
		if (f.isDirectory()) {
			File[] files = f.listFiles();
			for (int i = 0; i < files.length; ++i) {
				remover(files[i]);
			}
		}
		f.delete();
	}

	/**
	 * Metodo que carrega o sistema a partir de arquivos salvos anteriormente.
	 */
	public void carregarSistema() {
		File file = new File("arquivos" + File.separator + "comissoes.dat");
		File file1 = new File("arquivos" + File.separator + "pessoas.dat");
		File file2 = new File("arquivos" + File.separator + "partidos.dat");
		File file3 = new File("arquivos" + File.separator + "proposicoes.dat");
		try {
			ObjectInputStream inp = new ObjectInputStream(new FileInputStream(file));
			ObjectInputStream inp1 = new ObjectInputStream(new FileInputStream(file1));
			ObjectInputStream inp2 = new ObjectInputStream(new FileInputStream(file2));
			ObjectInputStream inp3 = new ObjectInputStream(new FileInputStream(file3));
			this.comissaoController = (ComissaoController) inp.readObject();
			this.pessoaController = (PessoaController) inp1.readObject();
			this.partidoController = (PartidoBaseGovernistaController) inp2.readObject();
			this.proposicaoController = (ProposicaoController) inp3.readObject();
			inp.close();
			inp1.close();
			inp2.close();
			inp3.close();
		} catch (FileNotFoundException e) {

		} catch (ClassNotFoundException e) {

		} catch (IOException e) {

		}
	}
}