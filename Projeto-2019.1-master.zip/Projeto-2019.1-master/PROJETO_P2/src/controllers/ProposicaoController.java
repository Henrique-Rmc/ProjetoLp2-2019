package controllers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import eco.proposicao.PEC;
import eco.proposicao.PL;
import eco.proposicao.PLP;
import eco.proposicao.ProposicaoLegislativa;
import validador.Validador;

/**
 * Controller de uma proposicao, responsavel por controlar e manter o registro
 * do conjuto de proposicoes.
 * 
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */

public class ProposicaoController implements Serializable {

	/** Conjunto de proposicoes. */
	private Map<String, ProposicaoLegislativa> proposicoes;
	/** Validador de dados. */
	private Validador validador;

	/** Constroi um proposicao controller. */
	public ProposicaoController() {
		this.proposicoes = new LinkedHashMap<>();
		this.validador = new Validador();
	}

	/**
	 * Metodo que realiza a contagem de proposicoes de um mesmo tipo em um mesmo
	 * tempo para se obter o codigo da proposicao.
	 * 
	 * @param tipo o tipo da proposicao.
	 * @param ano  o ano da proposicao.
	 * @return um inteiro indicado o numero da proposicao naquele ano.
	 */
	private int contaProposicao(String tipo, int ano) {
		int conta = 1;
		for (String p : proposicoes.keySet()) {
			String[] chave = p.split(" ");
			if (chave[0].equals(tipo)) {
				if (Integer.parseInt(chave[1].split("/")[1]) == ano)
					conta++;
			}
		}
		return conta;
	}

	/**
	 * Metodo que realiza o cadastro de uma proposicao do tipo PL no sistema.
	 * 
	 * @param dni        o dni do deputado que realizou a proposicao.
	 * @param ano        o ano da proposicao.
	 * @param ementa     pequena descricao do projeto.
	 * @param interesses os interesses relacionados ao projeto.
	 * @param url        o endereco do documento.
	 * @param conclusivo indica se a proposta so precisa ser apreciada nas comissoes
	 *                   e nao precisa ir ao plenario.
	 * @return uma String com o codigo da PL.
	 */
	public String cadastrarPL(String dni, int ano, String ementa, String interesses, String url, boolean conclusivo) {
		this.validador.validaString(dni, "Erro ao cadastrar projeto: autor nao pode ser vazio ou nulo");
		this.validador.validaString(ementa, "Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		this.validador.validaString(interesses, "Erro ao cadastrar projeto: interesse nao pode ser vazio ou nulo");
		this.validador.validaString(url, "Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		this.validador.validaDni(dni, "Erro ao cadastrar projeto: dni invalido");
		this.validador.validaAnoProposicao(ano, "Erro ao cadastrar projeto: ");

		int contaPL = this.contaProposicao("PL", ano);
		String codigo = String.format("PL %d/%d", contaPL, ano);

		String[] interessesSeparados = interesses.split(",");
		List<String> todosInteresses = new ArrayList<>();
		for (String interesse : interessesSeparados) {
			todosInteresses.add(interesse);
		}

		proposicoes.put(codigo, new PL(codigo, dni, ano, ementa, todosInteresses, url, conclusivo));
		return codigo;
	}

	/**
	 * Metodo que realiza o cadastro de uma proposicao do tipo PLP no sistema.
	 * 
	 * @param dni        o dni do deputado que realizou a proposicao.
	 * @param ano        o ano da proposicao.
	 * @param ementa     pequena descricao do projeto.
	 * @param interesses os interesses relacionados ao projeto.
	 * @param url        o endereco do documento.
	 * @param artigos    os artigos da constitucao a serem complementados ou
	 *                   emendados.
	 * @return uma String com o codigo da PLP.
	 */
	public String cadastrarPLP(String dni, int ano, String ementa, String interesses, String url, String artigos) {
		this.validador.validaString(dni, "Erro ao cadastrar projeto: autor nao pode ser vazio ou nulo");
		this.validador.validaString(ementa, "Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		this.validador.validaString(artigos, "Erro ao cadastrar projeto: artigo nao pode ser vazio ou nulo");
		this.validador.validaString(interesses, "Erro ao cadastrar projeto: interesse nao pode ser vazio ou nulo");
		this.validador.validaString(url, "Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		this.validador.validaDni(dni, "Erro ao cadastrar projeto: dni invalido");
		this.validador.validaAnoProposicao(ano, "Erro ao cadastrar projeto: ");

		int contaPLP = this.contaProposicao("PLP", ano);
		String codigo = String.format("PLP %d/%d", contaPLP, ano);
		List<String> todosInteresses = this.separaInteresses(interesses);

		proposicoes.put(codigo, new PLP(codigo, dni, ano, ementa, todosInteresses, url, artigos));
		return codigo;
	}

	/**
	 * Metodo que realiza o cadastro de uma proposicao do tipo PEC no sistema.
	 * 
	 * @param dni        o dni do deputado que realizou a proposicao.
	 * @param ano        o ano da proposicao.
	 * @param ementa     pequena descricao do projeto.
	 * @param interesses lista de interesses relacionados ao projeto.
	 * @param url        o endereco do documento.
	 * @param artigos    os artigos da constitucao a serem complementados ou
	 *                   emendados.
	 * @return uma String com o codiigo da PEC.
	 */
	public String cadastrarPEC(String dni, int ano, String ementa, String interesses, String url, String artigos) {
		this.validador.validaString(dni, "Erro ao cadastrar projeto: autor nao pode ser vazio ou nulo");
		this.validador.validaString(ementa, "Erro ao cadastrar projeto: ementa nao pode ser vazia ou nula");
		this.validador.validaString(artigos, "Erro ao cadastrar projeto: artigo nao pode ser vazio ou nulo");
		this.validador.validaString(interesses, "Erro ao cadastrar projeto: interesse nao pode ser vazio ou nulo");
		this.validador.validaString(url, "Erro ao cadastrar projeto: url nao pode ser vazio ou nulo");
		this.validador.validaDni(dni, "Erro ao cadastrar projeto: dni invalido");
		this.validador.validaAnoProposicao(ano, "Erro ao cadastrar projeto: ");

		int contaPEC = this.contaProposicao("PEC", ano);
		String codigo = String.format("PEC %d/%d", contaPEC, ano);
		List<String> todosInteresses = this.separaInteresses(interesses);

		proposicoes.put(codigo, new PEC(codigo, dni, ano, ementa, todosInteresses, url, artigos));
		return codigo;
	}

	/**
	 * Metodo auxiliar que separa em uma lista os interesses de uma proposta
	 * recebido como String.
	 * 
	 * @param interesses uma String com os interesses de uma proposta.
	 * @return uma Lista com os interesses da proposta, agora separados.
	 */
	private List<String> separaInteresses(String interesses) {
		String[] interessesSeparados = interesses.split(",");
		List<String> todosInteresses = new ArrayList<>();
		for (String interesse : interessesSeparados) {
			todosInteresses.add(interesse);
		}
		return todosInteresses;
	}

	/**
	 * Metodo que exibe um Projeto de lei a partir do seu codigo.
	 * 
	 * @param codigo o codigo do projeto.
	 * @return a representacao em String do projeto.
	 */
	public String exibirProjeto(String codigo) {
		if (!proposicoes.containsKey(codigo))
			throw new NullPointerException("Erro ao exibir projeto: projeto nao existe");

		return proposicoes.get(codigo).toString();
	}

	/**
	 * Metedo acessorio que verifica se um projeto ja esta cadastrado no sistema.
	 * 
	 * @param codigo o codigo do projeto a ser verificado.
	 * @return um boolean que indica se o projeto esta ou nao cadastrado no sistema.
	 */
	public boolean containsProjeto(String codigo) {
		return proposicoes.containsKey(codigo);
	}

	/**
	 * Metodo que retorna a situacao de um projeto.
	 * 
	 * @param codigo o codigo do projeto a ser verificado.
	 * @return uma String com a situacao atual do projeto.
	 */
	public String getSituacao(String codigo) {
		return proposicoes.get(codigo).getSituacaoAtual();
	}

	/**
	 * Metodo que adiciona detalhes sobre a tramitacao do projeto.
	 * 
	 * @param codigo  o codigo do projeto.
	 * @param tramite o detalhe a ser adicionado
	 */
	public void addTramite(String codigo, String tramite) {
		proposicoes.get(codigo).adicionaTramite(tramite);
	}

	/**
	 * Metodo que altera a situacao atual de um projeto sendo passados eu codigo e a
	 * nova situacao.
	 * 
	 * @param codigo o codigo do projeto a ser alterada a situacao.
	 * @param s      o novo status da situacao.
	 */
	public void setSituacaoAtual(String codigo, String s) {
		proposicoes.get(codigo).setSituacaoAtual(s);
	}

	/**
	 * Metodo que retorna se um projeto é do tipo conclusivo ou nao, ou seja, indica
	 * se a proposta so precisa ser apreciada nas comissoes, e nao precisa ir ao
	 * plenario.
	 * 
	 * @param codigo o codigo do projeto a ser verificado.
	 * @return o boolean que indica se o projeto e conclusivo ou nao.
	 */
	public boolean getConclusivo(String codigo) {
		return this.proposicoes.get(codigo).getConclusivo();
	}

	/**
	 * Metodo que retorna uma Lista de Strings com os interesses de um projeto a
	 * partir de seu codigo.
	 * 
	 * @param codigo o codigo do projeto.
	 * @return uma Lista de Strings com os interesses do projeto.
	 */
	public List<String> getInteresses(String codigo) {
		return this.proposicoes.get(codigo).getInteresses();
	}

	/**
	 * Metodo que retorna uma String com o autor do Projeto a partir do seu codigo.
	 * 
	 * @param codigo o codigo do projeto.
	 * @return uma String com o autor do projeto.
	 */
	public String getAutor(String codigo) {
		return this.proposicoes.get(codigo).getAutor();
	}

	/**
	 * Metodo que retorna o tipo de um Projeto, podendo ser PEC, PL ou PLP a partir
	 * do seu codigo.
	 * 
	 * @param codigo o codigo do projeto.
	 * @return uma String com o tipo do Projeto.
	 */
	public String getTipo(String codigo) {
		return this.proposicoes.get(codigo).getTipo();
	}

	/**
	 * Metodo que retorna uma Lista de Strings com todos os tramites de uma
	 * proposicao.
	 * 
	 * @param codigo o codigo da proposta.
	 * @return uma lista de Strings com todos os tramites de uma proposicao.
	 */
	public List<String> getTramitacao(String codigo) {
		return this.proposicoes.get(codigo).getTramitacao();
	}

	/**
	 * Metodo auxiliar que remove o ultimo tramite de uma proposicao.
	 * 
	 * @param codigo o codigo da proposta.
	 */
	public void removeUltimoTramite(String codigo) {
		this.proposicoes.get(codigo).removeUltimoTramite();
	}

	/**
	 * Metodo que retorna uma lista de propostas relacionadas com os interesses de
	 * uma pessoa.
	 * 
	 * @param interessesPessoa uma lista de Strings com os interesses de uma pessoa.
	 * @return uma lista com as propostas relacionadas com os interesses de uma
	 *         pessoa.
	 */
	public List<ProposicaoLegislativa> selecionaProposicoesComMesmoInteresse(List<String> interessesPessoa) {
		List<ProposicaoLegislativa> plSelecionadas = new ArrayList<>();
		for (ProposicaoLegislativa pl : this.proposicoes.values()) {
			List<String> interessesPl = pl.getInteresses();
			if (this.verificaInteressesEmComum(interessesPl, interessesPessoa)) {
				if (!pl.verificaProjetoEncerrado()) {
					plSelecionadas.add(pl);
				}
			}
		}
		return plSelecionadas;
	}

	/**
	 * Metodo que verifica se existem interesses em comum entre uma pessoa e uma
	 * proposta legislativa.
	 * 
	 * @param interessesPl     lista de interesses de uma proposta.
	 * @param interessesPessoa lista de interesses de uma pessoa.
	 * @return um boolean, True caso exista pelo menos um interesse em comum entre
	 *         uma pessoa e uma proposta legislativa e False caso não exista nenhum
	 *         interesse em comum.
	 */
	private boolean verificaInteressesEmComum(List<String> interessesPl, List<String> interessesPessoa) {
		for (String interesse : interessesPessoa) {
			if (interessesPl.contains(interesse))
				return true;
		}
		return false;
	}

	public int contaInteressesEmComum(String codigo, List<String> interessesPessoa) {
		return proposicoes.get(codigo).contaInteressesEmComum(interessesPessoa);
	}

	/**
	 * Metodo auxiliar que verifica se existe quorum suficiente para votar uma
	 * proposta a partir do seu codigo, lista de deputados presentes e o numero
	 * total de deputados.
	 * 
	 * @param codigo             o codigo da proposta.
	 * @param deputadosPresentes a lista de deputados presentes.
	 * @param totalDeputados     o numero total de deputados.
	 */
	public void verificaQuorum(String codigo, int deputadosPresentes, int totalDeputados) {
		if (!this.proposicoes.get(codigo).verificaQuorum(deputadosPresentes, totalDeputados)) {
			throw new IllegalArgumentException("Erro ao votar proposta: quorum invalido");
		}

	}

	/**
	 * Metodo auxiliar que verifica se um projeto ja foi encerrado.
	 * 
	 * @param codigo o codigo do projeto a ser verificado.
	 */
	public void verificaProjetoEncerrado(String codigo) {
		if (this.proposicoes.get(codigo).verificaProjetoEncerrado()) {
			throw new IllegalArgumentException("Erro ao votar proposta: tramitacao encerrada");
		}

	}

	/**
	 * Metodo que retorna o resultado de uma votacao no Plenario.
	 * 
	 * @param codigo             o codigo da proposta.
	 * @param deputadosPresentes a lista de deputados presentes na votacao.
	 * @param localAtual         o local atual que se encontra a proposta.
	 * @param totalDeputados     o numero total de deputados.
	 * @param votosFavoraveis    a quantidade de votos favoraveis a votacao da
	 *                           proposta.
	 * @return um boolean True caso a proposta tenha sido aprovada e False caso
	 *         contrario.
	 */
	public boolean resultadoVotacaoPlenario(String codigo, int deputadosPresentes, String localAtual,
			int totalDeputados, int votosFavoraveis) {
		return proposicoes.get(codigo).resultadoVotacaoPlenario(deputadosPresentes, localAtual, totalDeputados,
				votosFavoraveis);
	}

	/**
	 * Metodo que retorna o resultado de uma votacao em uma Comissao.
	 * 
	 * @param codigo            o codigo da proposta.
	 * @param localAtual        o local atual que se encontra a proposta.
	 * @param proximoLocal      o proximo local da tramitacao da proposta
	 * @param resultadoVotacao  o valor booleano do resultado da votacao
	 */
	public void registraVotacaoComissao(String codigo, String localAtual, String proximoLocal,
			boolean resultadoVotacao) {
		this.proposicoes.get(codigo).registraVotacaoComissao(localAtual, proximoLocal, resultadoVotacao);
	}

}