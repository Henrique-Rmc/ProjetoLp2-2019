package controllers;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import eco.pessoa.Deputado;
import eco.pessoa.Pessoa;
import eco.pessoa.estrategias.EstrategiaPropostaRelacionada;
import eco.proposicao.ProposicaoLegislativa;
import validador.Validador;

/**
 * Controller de Pessoa, responsavel por controlar e manter o registro do conjunto de pessoas.
 *  
 * @author Gustavo Farias de Souza Silva - 118210480
 * @author Paulo Henrique Ribeiro Medeiros Cruz - 118210460
 * @author Jonatha Kennedy Monteiro da Costa - 118210227
 * @author Lucas Oliveira Belmiro - 118210068
 * 
 */

public class PessoaController implements Serializable{
	
	/** Mapa contendo o nome como chave e o objeto Partido como valor. */
	private Map<String, Pessoa> pessoas;
	/** Objeto para validar os dados recebidos. */
	private Validador validacao;
	
	
	/** Constroi um Controller de Pessoa */
	public PessoaController() {
		this.pessoas = new HashMap<>();
		this.validacao = new Validador();
	}
	
	/**
	 * Cadastra um novo objeto Pessoa a partir do nome, do DNI, do estado e dos interesses da pessoa.
	 * 
	 * @param nome o nome da pessoa
	 * @param dni o DNI da pessoa
	 * @param estado o estado de localidade da pessoa
	 * @param interesses os interesses da pessoa
	 */
	public void cadastrarPessoa(String nome, String dni, String estado, String interesses) {
		this.validacao.validaString(nome, "Erro ao cadastrar pessoa: nome nao pode ser vazio ou nulo");
		this.validacao.validaString(dni, "Erro ao cadastrar pessoa: dni nao pode ser vazio ou nulo");
		this.validacao.validaString(estado, "Erro ao cadastrar pessoa: estado nao pode ser vazio ou nulo");
		this.validacao.validaDni(dni, "Erro ao cadastrar pessoa: dni invalido");
		if (this.pessoas.containsKey(dni))
			throw new IllegalArgumentException("Erro ao cadastrar pessoa: dni ja cadastrado");
		
		this.pessoas.put(dni, new Pessoa(nome, dni, estado, interesses));
	}
	
	/**
	 * Cadastra um novo objeto Pessoa a partir do nome, do DNI, do estado, dos interesses e do partido da pessoa.
	 * 
	 * @param nome o nome da pessoa
	 * @param dni o DNI da pessoa
	 * @param estado o estado de localidade da pessoa
	 * @param interesses os interesses da pessoa
	 * @param partido o partido da pessoa
	 */
	public void cadastrarPessoa(String nome, String dni, String estado, String interesses, String partido) {
		this.validacao.validaString(nome, "Erro ao cadastrar pessoa: nome nao pode ser vazio ou nulo");
		this.validacao.validaString(dni, "Erro ao cadastrar pessoa: dni nao pode ser vazio ou nulo");
		this.validacao.validaString(estado, "Erro ao cadastrar pessoa: estado nao pode ser vazio ou nulo");
		this.validacao.validaDni(dni, "Erro ao cadastrar pessoa: dni invalido");
		if (this.pessoas.containsKey(dni))
			throw new IllegalArgumentException("Erro ao cadastrar pessoa: dni ja cadastrado");
		
		this.pessoas.put(dni, new Pessoa(nome, dni, estado, interesses, partido));
	}
	
	/**
	 * Cadastra um Deputado a partir da data de inicio da mandato, passada como parametro,
	 * e adiciona como funcionalidade a pessoa associada ao DNI tambem passado como parametro.
	 * 
	 * @param dni o DNI da pessoa
	 * @param dataDeInicio a data de inicio do mandato do deputado
	 */
	public void cadastraDeputado(String dni, String dataDeInicio) {
		this.validacao.validaString(dni, "Erro ao cadastrar deputado: dni nao pode ser vazio ou nulo");
		this.validacao.validaDni(dni, "Erro ao cadastrar deputado: dni invalido");
		if (!this.pessoas.containsKey(dni))
			throw new NullPointerException("Erro ao cadastrar deputado: pessoa nao encontrada");
		if (this.pessoas.get(dni).getPartido().isEmpty())
			throw new NullPointerException("Erro ao cadastrar deputado: pessoa sem partido");
		this.validacao.validaString(dataDeInicio, "Erro ao cadastrar deputado: data nao pode ser vazio ou nulo");
		this.validacao.validaData(dataDeInicio, "Erro ao cadastrar deputado: data");
		
		this.pessoas.get(dni).setFuncao(new Deputado(dataDeInicio));
	}
	
	/**
	 * Retorna a String que representa a pessoa cadastrada a partir do DNI passado como parametro.
	 * 
	 * @param dni o DNI da pessoa
	 * @return a representacao em String da pessoa
	 */
	public String exibePessoa(String dni) {
		this.validacao.validaString(dni, "Erro ao exibir pessoa: dni nao pode ser vazio ou nulo");
		this.validacao.validaDni(dni, "Erro ao exibir pessoa: dni invalido");
		if (!this.pessoas.containsKey(dni))
			throw new NullPointerException("Erro ao exibir pessoa: pessoa nao encontrada");
		
		return this.pessoas.get(dni).getDetalhes();
	}
	
	/**
	 * Metodo que verifica se uma pessoa esta cadastrada no sistema a partir do seu DNI.
	 * @param dni o identificador da pessoa.
	 * @return um boolean que indica se a pessoa esta ou nao cadastrada no sistema.
	 */
	public boolean existePessoa(String dni) {
		return this.pessoas.containsKey(dni);
	}
	
	/**
	 * Metodo que retorna a funcao de uma pessoa, podendo ser Cidadao ou Deputado.
	 * @param dni o identificador da pessoa.
	 * @return uma String com a funcao da pessoa.
	 */
	public String exibeFuncao(String dni) {
		return this.pessoas.get(dni).getFuncao();
	}
	
	/**
	 * Metodo que retorna o partido de uma pessoa.
	 * @param dni o identificador da pessoa.
	 * @return uma String com a funcao da pessoa.
	 */
	public String getPartido(String dni) {
		return this.pessoas.get(dni).getPartido();
	}
	
	/**
	 * Metodo que retorna uma lista de Strings contendo os interesses de uma pessoa.
	 * @param dni o identificador de uma pessoa.
	 * @return uma lista de Strings contendo os interesses de uma pessoa.
	 */
	public List<String> getInteresses(String dni) {
		return this.pessoas.get(dni).getInteresses();
	}
	
	/**
	 * Metodo que adiciona um projeto de lei a um deputado.
	 * @param dni o identificador do deputado.
	 */
	public void addLeiDeputado(String dni) {
		this.pessoas.get(dni).addLeiDeputado();
	}
	
	/**
	 * Método que conta o numero de deputados cadastrados no sistema.
	 * @return um inteiro com o numero de deputados.
	 */
	public int contaDeputados() {
		int contagem = 0;
		for (Pessoa p : pessoas.values()) {
			if (p.getFuncao().equals("Deputado")) {
				contagem++;
			}
		} return contagem;
	}
	
	/**
	 * Metodo que altera a forma de selecionar a proposta mais relacionada com a pessoa.
	 * @param dni o dni da pessoa.
	 * @param estrategia a nova estrategia.
	 */
	public void setEstrategia(String dni, EstrategiaPropostaRelacionada estrategia) {
		this.pessoas.get(dni).setEstrategia(estrategia);
	}
	
	/**
	 * Metodo que retorna a proposta legislativa mais relacionada a uma pessoa de acordo com seus interesses.
	 * @param dni o dni da pessoa.
	 * @param pls lista de propostas legislativas.
	 * @return uma String com a proposta legislativa mais relacionada.
	 */
	public String selecionaPropostaRelacionada(String dni, List<ProposicaoLegislativa> pls) {
		return this.pessoas.get(dni).selecionaPropostaRelacionada(pls);
	}
	
}